





<!DOCTYPE html>
<html lang="en" data-color-mode="auto" data-light-theme="light" data-dark-theme="dark" >
  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://github.githubassets.com">
  <link rel="dns-prefetch" href="https://avatars.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">
  <link rel="preconnect" href="https://github.githubassets.com" crossorigin>
  <link rel="preconnect" href="https://avatars.githubusercontent.com">



  <link crossorigin="anonymous" media="all" integrity="sha512-sD8zc/Dn1lguLc4FdbeVhD2gfxFCTXGr/y+MpJG3oX1vkAyaFf/7BHPtvv1dAHA0KG4bDEW3Ex1EPrzGTMtN2Q==" rel="stylesheet" href="https://github.githubassets.com/assets/light-b03f3373f0e7.css" /><link crossorigin="anonymous" media="all" integrity="sha512-V0872pNNqPTaPQFzdwX9tHIzJvB4F1Foi6VYDciZAMo/qHgBC8PvN2d/SkMweiNDbR6eF3cXcG0aPVrEtC8zqw==" rel="stylesheet" href="https://github.githubassets.com/assets/dark-574f3bda934d.css" /><link data-color-theme="dark_dimmed" crossorigin="anonymous" media="all" integrity="sha512-PzuUWYSTZfXfFMEstZYF7zd5TnBiunweYKf7SA0USRWwzNBPELoB8ZhGVGTwcMSwF5ff9kyBAdGzEbfJ2/4cig==" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_dimmed-3f3b94598493.css" /><link data-color-theme="dark_high_contrast" crossorigin="anonymous" media="all" integrity="sha512-PDguTqV/sgFBBIdGLWGe50pI4GUQjVg3NQIm1ue9+6Wtn5qdx122aGJ1/M6IydIYhVs1tRfeLBl8P+7lNRRHlg==" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_high_contrast-3c382e4ea57f.css" /><link data-color-theme="dark_colorblind" crossorigin="anonymous" media="all" integrity="sha512-PZ0pkh4DltajJswDsmdCrHotI3eS5qb+etb48dcRDxUuiy0g2YP+kw5sQi04CE7AO+J33JXg86PAQoivVKkdKg==" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_colorblind-3d9d29921e03.css" /><link data-color-theme="light_colorblind" crossorigin="anonymous" media="all" integrity="sha512-P+VDoZFVyqfAb06foA/ZLUzHkdMPqEQq1d1B0VSzEzOF3fidwKWULgI+b1E+OoF7VnC5HXRS4lMJPKKc6wrc8g==" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_colorblind-3fe543a19155.css" /><link data-color-theme="light_high_contrast" crossorigin="anonymous" media="all" integrity="sha512-33ulzUgAM4pZv65KAcvjwZLHiC4bQaF61LiK9BiAQ/kuCG/+LtNi2clT1gfb72sa9SOsiu4fs4bEBL543Ms3Iw==" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_high_contrast-df7ba5cd4800.css" />
    <link crossorigin="anonymous" media="all" integrity="sha512-5ZbigSI73OYW3WqZvG2pPmYxOIsJngYy4HrcOGIjDt1+URG7sbCb6YjiN5iy/vVidod+FkOpKkRNioN0ZYv0Zg==" rel="stylesheet" href="https://github.githubassets.com/assets/frameworks-e596e281223b.css" />
    <link crossorigin="anonymous" media="all" integrity="sha512-7Dp/Zn9znRUkNm2NwTxEffb35FWsEJ69QZzWQPCvBH4db3zFaAlN4w6oBQQijMYVQh8Tq80AZcAM2D8bcwZx8g==" rel="stylesheet" href="https://github.githubassets.com/assets/behaviors-ec3a7f667f73.css" />
  <link crossorigin="anonymous" media="all" integrity="sha512-NgSGUxQBx293/VPzlnacDZfQCBu+lzrGG4LyesKxlqdO9MKh4dEcFsbM0Qn1VgII7Px9CyhPallf6rKvATqh5g==" rel="stylesheet" href="https://github.githubassets.com/assets/github-360486531401.css" />



  <script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-BXfAcabxI+2Tv0ii84WvQYP/xpMD8fxO0m/Lun3AAJhKvd8O78cLzpoeXa8SmCtvs8Lm0TEph8q3VagW8IG9TQ==" src="https://github.githubassets.com/assets/runtime-0577c071a6f1.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-/60A2/6dLC43TT9rA0QBLRuG9Sreq8FCULwAwUt8sxZWcDMhjHyiYSSO6TaEEcnb55AnhIBJTcgjkuoqcK8iKQ==" src="https://github.githubassets.com/assets/environment-ffad00dbfe9d.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-mNt9opq5jyqeZdWMV25dquh3PeAJZk/NFBfdGMUbTN7JB344FlZu6Jr8g/ieGGy+3sy5REA/uZXM0GmGKqOpcw==" src="https://github.githubassets.com/assets/5329-98db7da29ab9.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-9n/KDFl7RTBwlMhFd7BrFVXj5dJnvyMjRzKu4rxr4eKDf8zqcP3hbZVzCiBdR0e0jS2L8asQfzsnHSK2c+ZF7g==" src="https://github.githubassets.com/assets/2486-f67fca0c597b.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-qNL70NcbKIFaK7Pc/pynQJLTpp1jZIBaFA7o31IrfbYEiuDqi/TnCkEU4QxKSVaLxtt5B1Y6zNRz2iUgqaqdew==" src="https://github.githubassets.com/assets/8475-a8d2fbd0d71b.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-H/F50N+M9z2+JkI/7v34Hcedrm01LD6TPomVD3jiqhDkjk/uIAate1EKFGfoQOT+jJGEOuWw7zxoXd/MpeD6qg==" src="https://github.githubassets.com/assets/github-elements-1ff179d0df8c.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-gMuArzh/AUToSuEdQs/X6+1Y9VTfQ/mUDp0RntomyKb9Z+XaTejHFO59pjqTRX4Vo4CA2JDmSLD69nvKoxGxvw==" src="https://github.githubassets.com/assets/element-registry-80cb80af387f.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-ZAKZQWCEc6bs9LSQOCPRWq3wqRDkQxG2bPL/pW9Lj/Seap0PV0kF/yKCHske8mW3Zytde9n1Im83jxrCmpaMrA==" src="https://github.githubassets.com/assets/5724-640299416084.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-Hb8d69V10VxkC90NX3zvjNovHq5vrRv0XCde5qNf5WiQAB6BziCN+gEbKG+fDj8i05B2pBdyGIh+3pmaRvzLJA==" src="https://github.githubassets.com/assets/5388-1dbf1debd575.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-j9tCiIT7h+++Hko9qwRezOfoO32kBBlf6Te9zZyxxmrxG1EA5ji2QCYAIzd5vXB7616gZ5m9J+WMQwv3VEf1wA==" src="https://github.githubassets.com/assets/93-8fdb428884fb.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-JPHg6lXC/kVMbA05VoaD5W739fMUF/ObaJ4NrZWLi91OWI9xEhJ9NtwbGROmxjCm5FGwNOVohY+DXILkO19dtA==" src="https://github.githubassets.com/assets/8932-24f1e0ea55c2.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-heG3JMoQq3ducVj0rke7ixXR6HU4XKtSlNnKQ6uGDD+JjKmcpeXRiBBQnX1biRw9F33Eyqkqv7wifIWv4lEk/Q==" src="https://github.githubassets.com/assets/1717-85e1b724ca10.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-n2oK+L9azw6RosotvTCUd1Jxr802Hv6tJyGrbiZO2D0Dy1kWE/qXLS6fPc7EcQH5DiSpLHJsySDgDRuC40TbUA==" src="https://github.githubassets.com/assets/901-9f6a0af8bf5a.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-/V7241I4oTyrmfzf1ZLgzrDMftUwrGlFXG26BaMgW8Koi8/8InvjGu+skviYVpZN5G4FOCsUNoE3zS6R73Sqgg==" src="https://github.githubassets.com/assets/3682-fd5ef6e35238.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-HAkxnw9T7k6o8jrwnCU02jjyGxcy4XwAFi4EahWVnXfnZNapkX5FKajEOzz7QakIoYSzQYxKHedPAhw8RuwAsw==" src="https://github.githubassets.com/assets/3932-1c09319f0f53.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-6Z042pDIkQL8gBC8c8IuDLV2NrsRl4D0rQ/zMAIpjGgSWuzL3H0iXADdpwlB/L00dl0Nus2uL3JBUcQYcWPP0w==" src="https://github.githubassets.com/assets/3826-e99d38da90c8.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-yvzIhSyniMQb1fkQ7iaHIxqVCwk34Zd7jEqriSPiBq4N+M4hHPyOhOQYnBupCQwgwE6iHHbWPQpX18Hu4HXVfQ==" src="https://github.githubassets.com/assets/5222-cafcc8852ca7.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-0KPr1fHNh0XrNfoQFV9QP/CoP23cBaiLkh8ko8ehOeZyS5Xwrz3jWm+wD1/qTsNf5Pg4jOyDj0tgjeDR4ENtNQ==" src="https://github.githubassets.com/assets/behaviors-d0a3ebd5f1cd.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-gy8qIM5ywfZwY9t64qGa3rDcqWJGKXayF+CsUt0owghpz2eqnNX2tMtSRRdOybIIwu6cScH/b8SkXvSHQt5qow==" src="https://github.githubassets.com/assets/7749-832f2a20ce72.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-XWCpyEQy0ukcAhCgvebb7RhB3Gl9ap6gzdKXsD2zOb099rINj1JJNqwQl3xCEzq4VQKz0OTVRe+2f9RiPrEBcQ==" src="https://github.githubassets.com/assets/notifications-global-5d60a9c84432.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-j9aa4mY3RsVxl/T9t17vcUmtCLfAGlx0vKa5aoA0OsheuVU1hhkLZ1ZRV1TsShVhC8TfEy3A1QvfMnSVPJ0VGw==" src="https://github.githubassets.com/assets/6852-8fd69ae26637.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-WD01XRUifYLpqYDvObFvpBisPrKgq4iJBDc0q7DTAGcCY9HHyVxTm9f7KoF5x4Yr9cuTle3MT1+4em0avCkLVQ==" src="https://github.githubassets.com/assets/4569-583d355d1522.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-auAt20R/NRpYpa48Og6dODiKuRrzM7DC9fHasdAti9A3p45nLatyBWjvNNuSpultmXuAeV8wYNvbHEZvnZKHnQ==" src="https://github.githubassets.com/assets/settings-6ae02ddb447f.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-/QnNfrtPvmUtXFREsM6OvLI7lkZhg8+obxxDMbTLmhpvIMIY8gKEVpKxdCA9YWxIsZntYFMlkhQkGKQAkNwC5A==" src="https://github.githubassets.com/assets/sessions-fd09cd7ebb4f.js"></script>
    <script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-PZOInk2+47XdtbA0tM0VFGa22YDelv0gT0IpMKnkBoFuS4zlmI8bAsMi6pRD+owH2f+8SJcpwwmc3x8zgXYiLw==" src="https://github.githubassets.com/assets/unsupported-3d93889e4dbe.js"></script>


  <meta name="viewport" content="width=device-width">
  
  <title>Sign in to GitHub · GitHub</title>
    <meta name="description" content="GitHub is where people build software. More than 73 million people use GitHub to discover, fork, and contribute to over 200 million projects.">
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">
  
    <meta property="og:url" content="https://github.com">
    <meta property="og:site_name" content="GitHub">
    <meta property="og:title" content="Build software better, together">
    <meta property="og:description" content="GitHub is where people build software. More than 73 million people use GitHub to discover, fork, and contribute to over 200 million projects.">
    <meta property="og:image" content="https://github.githubassets.com/images/modules/open_graph/github-logo.png">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="1200">
    <meta property="og:image" content="https://github.githubassets.com/images/modules/open_graph/github-mark.png">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="620">
    <meta property="og:image" content="https://github.githubassets.com/images/modules/open_graph/github-octocat.png">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="620">

    <meta property="twitter:site" content="github">
    <meta property="twitter:site:id" content="13334762">
    <meta property="twitter:creator" content="github">
    <meta property="twitter:creator:id" content="13334762">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:title" content="GitHub">
    <meta property="twitter:description" content="GitHub is where people build software. More than 73 million people use GitHub to discover, fork, and contribute to over 200 million projects.">
    <meta property="twitter:image:src" content="https://github.githubassets.com/images/modules/open_graph/github-logo.png">
    <meta property="twitter:image:width" content="1200">
    <meta property="twitter:image:height" content="1200">



    

  <link rel="assets" href="https://github.githubassets.com/">
  

  <meta name="request-id" content="1308:5537:302EFA:524DB0:6247D953" data-pjax-transient="true" /><meta name="html-safe-nonce" content="83532376a706c9eb55417b8fffe7fa0806ec21d9236b56f41282f3834a14b907" data-pjax-transient="true" /><meta name="visitor-payload" content="eyJyZWZlcnJlciI6Imh0dHA6Ly9naXRodWIuY29tL21lYmphcy9tZWJqYXMuZ2l0aHViLmlvL2Jsb2IvbWFzdGVyL2Fzc2V0cy9yZXNlYXJjaC9leHBvc3VyZV9mdXNpb24vZWYuanMiLCJyZXF1ZXN0X2lkIjoiMTMwODo1NTM3OjMwMkVGQTo1MjREQjA6NjI0N0Q5NTMiLCJ2aXNpdG9yX2lkIjoiNjczODMzMjIxMzMzMjkyNDczOSIsInJlZ2lvbl9lZGdlIjoiaWFkIiwicmVnaW9uX3JlbmRlciI6ImlhZCJ9" data-pjax-transient="true" /><meta name="visitor-hmac" content="9913f51efccb2f3c646c3a6826aae511d41fc0589441e5cce96e2f4995a12f22" data-pjax-transient="true" />



  <meta name="github-keyboard-shortcuts" content="" data-pjax-transient="true" />

  

  <meta name="selected-link" value="/login" data-pjax-transient>

    <meta name="google-site-verification" content="c1kuD-K2HIVF635lypcsWPoD4kilo5-jA_wBFyT4uMY">
  <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
  <meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
  <meta name="google-site-verification" content="GXs5KoUUkNCoaAZn7wPN-t01Pywp9M3sEjnt_3_ZWPc">

<meta name="octolytics-url" content="https://collector.github.com/github/collect" />

  <meta name="analytics-location-query-strip" content="true" data-pjax-transient="true" />

  




  

      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">



      <meta name="expected-hostname" content="github.com">


    <meta name="enabled-features" content="MARKETPLACE_PENDING_INSTALLATIONS">


  <meta http-equiv="x-pjax-version" content="0d69f823fc3c006453dc9d5d2512515c0bb0f722ac41cdf135f17a6c749c7cde" data-turbo-track="reload">
  <meta http-equiv="x-pjax-csp-version" content="fae078b7b0f21a3e87927a83cac351f9689d75ae7723ea091b3b1ae42747c273" data-turbo-track="reload">
  <meta http-equiv="x-pjax-css-version" content="0795d9e2979067ce2a2178ac7e69af171aee8dced9639aaea610ac98d56bd2f3" data-turbo-track="reload">
  <meta http-equiv="x-pjax-js-version" content="d427542ab58bdbba04db6daf7cc8705964093198a21a0675bf9a257fe166a43b" data-turbo-track="reload">
  

      <link crossorigin="anonymous" media="all" integrity="sha512-NgSGUxQBx293/VPzlnacDZfQCBu+lzrGG4LyesKxlqdO9MKh4dEcFsbM0Qn1VgII7Px9CyhPallf6rKvATqh5g==" rel="stylesheet" href="https://github.githubassets.com/assets/github-360486531401.css" />



    <link rel="canonical" href="https://github.com/login" data-pjax-transient>


  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <meta name="browser-optimizely-client-errors-url" content="https://api.github.com/_private/browser/optimizely_client/errors">

  <link rel="mask-icon" href="https://github.githubassets.com/pinned-octocat.svg" color="#000000">
  <link rel="alternate icon" class="js-site-favicon" type="image/png" href="https://github.githubassets.com/favicons/favicon.png">
  <link rel="icon" class="js-site-favicon" type="image/svg+xml" href="https://github.githubassets.com/favicons/favicon.svg">

<meta name="theme-color" content="#1e2327">
<meta name="color-scheme" content="light dark" />


  <link rel="manifest" href="/manifest.json" crossOrigin="use-credentials">

  </head>

  <body class="logged-out env-production page-responsive session-authentication" style="word-wrap: break-word;">
    

    <div class="position-relative js-header-wrapper ">
      <a href="#start-of-content" class="px-2 py-4 color-bg-accent-emphasis color-fg-on-emphasis show-on-focus js-skip-to-content">Skip to content</a>
      <span data-view-component="true" class="progress-pjax-loader js-pjax-loader-bar Progress position-fixed width-full">
    <span style="width: 0%;" data-view-component="true" class="Progress-item progress-pjax-loader-bar left-0 top-0 color-bg-accent-emphasis"></span>
</span>      
      

          <div id="unsupported-browser" class="unsupported-browser" hidden>
  <div class="container-lg p-responsive clearfix d-flex flex-items-center py-2">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert mr-2 hide-sm color-fg-subtle">
    <path fill-rule="evenodd" d="M8.22 1.754a.25.25 0 00-.44 0L1.698 13.132a.25.25 0 00.22.368h12.164a.25.25 0 00.22-.368L8.22 1.754zm-1.763-.707c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0114.082 15H1.918a1.75 1.75 0 01-1.543-2.575L6.457 1.047zM9 11a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z"></path>
</svg>
    <div class="d-flex flex-auto flex-column flex-md-row">
      <div class="flex-auto min-width-0 mr-2" style="padding-top:1px">
        <span>GitHub no longer supports this web browser.</span>
        <a href="https://docs.github.com/articles/supported-browsers">
          Learn more about the browsers we support.
        </a>
      </div>
    </div>
  </div>
</div>



        <div class="header header-logged-out width-full pt-5 pb-4" role="banner">
  <div class="container clearfix width-full text-center">
    <a class="header-logo" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <svg height="48" aria-hidden="true" viewBox="0 0 16 16" version="1.1" width="48" data-view-component="true" class="octicon octicon-mark-github">
    <path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"></path>
</svg>
    </a>
  </div>
</div>


    </div>

  <div id="start-of-content" class="show-on-focus"></div>








    

  <include-fragment class="js-notification-shelf-include-fragment" data-base-src="https://github.com/notifications/beta/shelf"></include-fragment>





  <div
    class="application-main "
    data-commit-hovercards-enabled
    data-discussion-hovercards-enabled
    data-issue-and-pr-hovercards-enabled
  >
      <main id="js-pjax-container" data-pjax-container>
        


  <div class="auth-form px-3" id="login" >


      <input type="hidden" name="ga_id" class="js-octo-ga-id-input">
      <div class="auth-form-header p-0">
        <h1>Sign in to GitHub</h1>
      </div>


      <div data-pjax-replace id="js-flash-container">


  <template class="js-flash-template">
    <div class="flash flash-full  {{ className }}">
  <div class="px-2" >
    <button class="flash-close js-flash-close" type="button" aria-label="Dismiss this message">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
    </button>
    
      <div>{{ message }}</div>

  </div>
</div>
  </template>
</div>


      <div class="flash js-transform-notice" hidden>
        <button class="flash-close js-flash-close" type="button" aria-label="Dismiss this message">
          <svg aria-label="Dismiss" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
        </button>
      </div>

      <div class="auth-form-body mt-3">

          <!-- '"` --><!-- </textarea></xmp> --></option></form><form data-turbo="false" action="/session" accept-charset="UTF-8" method="post"><input type="hidden" name="authenticity_token" value="oyEaBzWUVEBwdrZFU__8t-enD2I-4yUB-FkFnzNNaf1LjVfg07k13H8BF_2C8Rh3KqC2HAOIEHtPAZ8xscYnhg" />  <label for="login_field">
    Username or email address
  </label>
  <input type="text" name="login" id="login_field" class="form-control input-block js-login-field" autocapitalize="off" autocorrect="off" autocomplete="username" autofocus="autofocus" />

  <div class="position-relative">
    <label for="password">
      Password
    </label>
    <input type="password" name="password" id="password" class="form-control form-control input-block js-password-field" autocomplete="current-password" />
    <input type="hidden" name="trusted_device" id="trusted_device" autocomplete="off" class="form-control" />
    
<input type="hidden" class="js-webauthn-support" name="webauthn-support" value="unknown">
<input type="hidden" class="js-webauthn-iuvpaa-support" name="webauthn-iuvpaa-support" value="unknown">
<input type="hidden" name="return_to" id="return_to" value="https://github.com/mebjas/mebjas.github.io/blob/master/assets/research/exposure_fusion/ef.js" autocomplete="off" class="form-control" />
<input type="hidden" name="allow_signup" id="allow_signup" autocomplete="off" class="form-control" />
<input type="hidden" name="client_id" id="client_id" autocomplete="off" class="form-control" />
<input type="hidden" name="integration" id="integration" autocomplete="off" class="form-control" />
<input type="text" name="required_field_6e7c" hidden="hidden" class="form-control" /><input type="hidden" name="timestamp" value="1648875859971" autocomplete="off" class="form-control" /><input type="hidden" name="timestamp_secret" value="6f267c76022ba7d5b3bda5bd6c9a723d1e01023ed007b80d048cd1df99bc589e" autocomplete="off" class="form-control" />

    <input type="submit" name="commit" value="Sign in" class="btn btn-primary btn-block js-sign-in-button" data-disable-with="Signing in…" data-signin-label="Sign in" data-sso-label="Sign in with your identity provider" development="false" />

    <a class="label-link position-absolute top-0 right-0" tabindex="0" href="/password_reset">Forgot password?</a>
  </div>
</form>
      </div>



        <p class="login-callout mt-3">
          New to GitHub?
          <a data-ga-click="Sign in, switch to sign up" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;sign in switch to sign up&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fmebjas%2Fmebjas.github.io%2Fblob%2Fmaster%2Fassets%2Fresearch%2Fexposure_fusion%2Fef.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="cf97e1e937372be188bd0ec2ce2667b14aab84067679db7402ea26dcb743d15c" href="/signup?return_to=https%3A%2F%2Fgithub.com%2Fmebjas%2Fmebjas.github.io%2Fblob%2Fmaster%2Fassets%2Fresearch%2Fexposure_fusion%2Fef.js&amp;source=login">Create an account</a>.
        </p>

  </div>

      </main>
  </div>

          <div class="footer container-lg p-responsive py-6 mt-6 f6" role="contentinfo">
    <ul class="list-style-none d-flex flex-justify-center">
        <li class="mr-3"><a href="/site/terms" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to terms&quot;,&quot;label&quot;:&quot;text:terms&quot;}">Terms</a></li>
        <li class="mr-3"><a href="/site/privacy" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to privacy&quot;,&quot;label&quot;:&quot;text:privacy&quot;}">Privacy</a></li>
        <li class="mr-3"><a href="https://docs.github.com/articles/github-security/" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to security&quot;,&quot;label&quot;:&quot;text:security&quot;}">Security</a></li>
          <li><a class="Link--secondary" data-ga-click="Footer, go to contact, text:contact" href="https://github.com/contact">Contact GitHub</a></li>
    </ul>
  </div>



  <div id="ajax-error-message" class="ajax-error-message flash flash-error" hidden>
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path fill-rule="evenodd" d="M8.22 1.754a.25.25 0 00-.44 0L1.698 13.132a.25.25 0 00.22.368h12.164a.25.25 0 00.22-.368L8.22 1.754zm-1.763-.707c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0114.082 15H1.918a1.75 1.75 0 01-1.543-2.575L6.457 1.047zM9 11a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z"></path>
</svg>
    <button type="button" class="flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
    </button>
    You can’t perform that action at this time.
  </div>

  <div class="js-stale-session-flash flash flash-warn flash-banner" hidden
    >
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path fill-rule="evenodd" d="M8.22 1.754a.25.25 0 00-.44 0L1.698 13.132a.25.25 0 00.22.368h12.164a.25.25 0 00.22-.368L8.22 1.754zm-1.763-.707c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0114.082 15H1.918a1.75 1.75 0 01-1.543-2.575L6.457 1.047zM9 11a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z"></path>
</svg>
    <span class="js-stale-session-flash-signed-in" hidden>You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
    <span class="js-stale-session-flash-signed-out" hidden>You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
  </div>
    <template id="site-details-dialog">
  <details class="details-reset details-overlay details-overlay-dark lh-default color-fg-default hx_rsm" open>
    <summary role="button" aria-label="Close dialog"></summary>
    <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast hx_rsm-dialog hx_rsm-modal">
      <button class="Box-btn-octicon m-0 btn-octicon position-absolute right-0 top-0" type="button" aria-label="Close dialog" data-close-dialog>
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
      </button>
      <div class="octocat-spinner my-6 js-details-dialog-spinner"></div>
    </details-dialog>
  </details>
</template>

    <div class="Popover js-hovercard-content position-absolute" style="display: none; outline: none;" tabindex="0">
  <div class="Popover-message Popover-message--bottom-left Popover-message--large Box color-shadow-large" style="width:360px;">
  </div>
</div>

    <template id="snippet-clipboard-copy-button">
  <div class="zeroclipboard-container position-absolute right-0 top-0">
    <clipboard-copy aria-label="Copy" class="ClipboardButton btn js-clipboard-copy m-2 p-0 tooltipped-no-delay" data-copy-feedback="Copied!" data-tooltip-direction="w">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copy js-clipboard-copy-icon m-2">
    <path fill-rule="evenodd" d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 010 1.5h-1.5a.25.25 0 00-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 00.25-.25v-1.5a.75.75 0 011.5 0v1.5A1.75 1.75 0 019.25 16h-7.5A1.75 1.75 0 010 14.25v-7.5z"></path><path fill-rule="evenodd" d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0114.25 11h-7.5A1.75 1.75 0 015 9.25v-7.5zm1.75-.25a.25.25 0 00-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 00.25-.25v-7.5a.25.25 0 00-.25-.25h-7.5z"></path>
</svg>
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check js-clipboard-check-icon color-fg-success d-none m-2">
    <path fill-rule="evenodd" d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"></path>
</svg>
    </clipboard-copy>
  </div>
</template>




  </body>
</html>

