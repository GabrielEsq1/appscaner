<ul class="list-style-none overflow-auto">
    <li class="Box-row">
      <a class="Link--primary no-underline" href="/mebjas">
        <img class="avatar mr-1 avatar-user" alt="" src="https://avatars.githubusercontent.com/u/3007365?s=40&amp;v=4" width="20" height="20" />
        mebjas
</a>    </li>
</ul>
