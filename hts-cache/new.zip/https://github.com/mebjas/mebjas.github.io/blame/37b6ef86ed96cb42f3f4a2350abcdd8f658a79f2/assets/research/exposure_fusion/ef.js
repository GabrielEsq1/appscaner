





<!DOCTYPE html>
<html lang="en" data-color-mode="auto" data-light-theme="light" data-dark-theme="dark" >
  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://github.githubassets.com">
  <link rel="dns-prefetch" href="https://avatars.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">
  <link rel="preconnect" href="https://github.githubassets.com" crossorigin>
  <link rel="preconnect" href="https://avatars.githubusercontent.com">



  <link crossorigin="anonymous" media="all" integrity="sha512-sD8zc/Dn1lguLc4FdbeVhD2gfxFCTXGr/y+MpJG3oX1vkAyaFf/7BHPtvv1dAHA0KG4bDEW3Ex1EPrzGTMtN2Q==" rel="stylesheet" href="https://github.githubassets.com/assets/light-b03f3373f0e7.css" /><link crossorigin="anonymous" media="all" integrity="sha512-V0872pNNqPTaPQFzdwX9tHIzJvB4F1Foi6VYDciZAMo/qHgBC8PvN2d/SkMweiNDbR6eF3cXcG0aPVrEtC8zqw==" rel="stylesheet" href="https://github.githubassets.com/assets/dark-574f3bda934d.css" /><link data-color-theme="dark_dimmed" crossorigin="anonymous" media="all" integrity="sha512-PzuUWYSTZfXfFMEstZYF7zd5TnBiunweYKf7SA0USRWwzNBPELoB8ZhGVGTwcMSwF5ff9kyBAdGzEbfJ2/4cig==" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_dimmed-3f3b94598493.css" /><link data-color-theme="dark_high_contrast" crossorigin="anonymous" media="all" integrity="sha512-PDguTqV/sgFBBIdGLWGe50pI4GUQjVg3NQIm1ue9+6Wtn5qdx122aGJ1/M6IydIYhVs1tRfeLBl8P+7lNRRHlg==" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_high_contrast-3c382e4ea57f.css" /><link data-color-theme="dark_colorblind" crossorigin="anonymous" media="all" integrity="sha512-PZ0pkh4DltajJswDsmdCrHotI3eS5qb+etb48dcRDxUuiy0g2YP+kw5sQi04CE7AO+J33JXg86PAQoivVKkdKg==" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_colorblind-3d9d29921e03.css" /><link data-color-theme="light_colorblind" crossorigin="anonymous" media="all" integrity="sha512-P+VDoZFVyqfAb06foA/ZLUzHkdMPqEQq1d1B0VSzEzOF3fidwKWULgI+b1E+OoF7VnC5HXRS4lMJPKKc6wrc8g==" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_colorblind-3fe543a19155.css" /><link data-color-theme="light_high_contrast" crossorigin="anonymous" media="all" integrity="sha512-33ulzUgAM4pZv65KAcvjwZLHiC4bQaF61LiK9BiAQ/kuCG/+LtNi2clT1gfb72sa9SOsiu4fs4bEBL543Ms3Iw==" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_high_contrast-df7ba5cd4800.css" />
    <link crossorigin="anonymous" media="all" integrity="sha512-5ZbigSI73OYW3WqZvG2pPmYxOIsJngYy4HrcOGIjDt1+URG7sbCb6YjiN5iy/vVidod+FkOpKkRNioN0ZYv0Zg==" rel="stylesheet" href="https://github.githubassets.com/assets/frameworks-e596e281223b.css" />
    <link crossorigin="anonymous" media="all" integrity="sha512-7Dp/Zn9znRUkNm2NwTxEffb35FWsEJ69QZzWQPCvBH4db3zFaAlN4w6oBQQijMYVQh8Tq80AZcAM2D8bcwZx8g==" rel="stylesheet" href="https://github.githubassets.com/assets/behaviors-ec3a7f667f73.css" />
  <link crossorigin="anonymous" media="all" integrity="sha512-NgSGUxQBx293/VPzlnacDZfQCBu+lzrGG4LyesKxlqdO9MKh4dEcFsbM0Qn1VgII7Px9CyhPallf6rKvATqh5g==" rel="stylesheet" href="https://github.githubassets.com/assets/github-360486531401.css" />



  <script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-BXfAcabxI+2Tv0ii84WvQYP/xpMD8fxO0m/Lun3AAJhKvd8O78cLzpoeXa8SmCtvs8Lm0TEph8q3VagW8IG9TQ==" src="https://github.githubassets.com/assets/runtime-0577c071a6f1.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-/60A2/6dLC43TT9rA0QBLRuG9Sreq8FCULwAwUt8sxZWcDMhjHyiYSSO6TaEEcnb55AnhIBJTcgjkuoqcK8iKQ==" src="https://github.githubassets.com/assets/environment-ffad00dbfe9d.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-mNt9opq5jyqeZdWMV25dquh3PeAJZk/NFBfdGMUbTN7JB344FlZu6Jr8g/ieGGy+3sy5REA/uZXM0GmGKqOpcw==" src="https://github.githubassets.com/assets/5329-98db7da29ab9.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-9n/KDFl7RTBwlMhFd7BrFVXj5dJnvyMjRzKu4rxr4eKDf8zqcP3hbZVzCiBdR0e0jS2L8asQfzsnHSK2c+ZF7g==" src="https://github.githubassets.com/assets/2486-f67fca0c597b.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-qNL70NcbKIFaK7Pc/pynQJLTpp1jZIBaFA7o31IrfbYEiuDqi/TnCkEU4QxKSVaLxtt5B1Y6zNRz2iUgqaqdew==" src="https://github.githubassets.com/assets/8475-a8d2fbd0d71b.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-H/F50N+M9z2+JkI/7v34Hcedrm01LD6TPomVD3jiqhDkjk/uIAate1EKFGfoQOT+jJGEOuWw7zxoXd/MpeD6qg==" src="https://github.githubassets.com/assets/github-elements-1ff179d0df8c.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-gMuArzh/AUToSuEdQs/X6+1Y9VTfQ/mUDp0RntomyKb9Z+XaTejHFO59pjqTRX4Vo4CA2JDmSLD69nvKoxGxvw==" src="https://github.githubassets.com/assets/element-registry-80cb80af387f.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-ZAKZQWCEc6bs9LSQOCPRWq3wqRDkQxG2bPL/pW9Lj/Seap0PV0kF/yKCHske8mW3Zytde9n1Im83jxrCmpaMrA==" src="https://github.githubassets.com/assets/5724-640299416084.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-Hb8d69V10VxkC90NX3zvjNovHq5vrRv0XCde5qNf5WiQAB6BziCN+gEbKG+fDj8i05B2pBdyGIh+3pmaRvzLJA==" src="https://github.githubassets.com/assets/5388-1dbf1debd575.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-j9tCiIT7h+++Hko9qwRezOfoO32kBBlf6Te9zZyxxmrxG1EA5ji2QCYAIzd5vXB7616gZ5m9J+WMQwv3VEf1wA==" src="https://github.githubassets.com/assets/93-8fdb428884fb.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-JPHg6lXC/kVMbA05VoaD5W739fMUF/ObaJ4NrZWLi91OWI9xEhJ9NtwbGROmxjCm5FGwNOVohY+DXILkO19dtA==" src="https://github.githubassets.com/assets/8932-24f1e0ea55c2.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-heG3JMoQq3ducVj0rke7ixXR6HU4XKtSlNnKQ6uGDD+JjKmcpeXRiBBQnX1biRw9F33Eyqkqv7wifIWv4lEk/Q==" src="https://github.githubassets.com/assets/1717-85e1b724ca10.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-n2oK+L9azw6RosotvTCUd1Jxr802Hv6tJyGrbiZO2D0Dy1kWE/qXLS6fPc7EcQH5DiSpLHJsySDgDRuC40TbUA==" src="https://github.githubassets.com/assets/901-9f6a0af8bf5a.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-/V7241I4oTyrmfzf1ZLgzrDMftUwrGlFXG26BaMgW8Koi8/8InvjGu+skviYVpZN5G4FOCsUNoE3zS6R73Sqgg==" src="https://github.githubassets.com/assets/3682-fd5ef6e35238.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-HAkxnw9T7k6o8jrwnCU02jjyGxcy4XwAFi4EahWVnXfnZNapkX5FKajEOzz7QakIoYSzQYxKHedPAhw8RuwAsw==" src="https://github.githubassets.com/assets/3932-1c09319f0f53.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-6Z042pDIkQL8gBC8c8IuDLV2NrsRl4D0rQ/zMAIpjGgSWuzL3H0iXADdpwlB/L00dl0Nus2uL3JBUcQYcWPP0w==" src="https://github.githubassets.com/assets/3826-e99d38da90c8.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-yvzIhSyniMQb1fkQ7iaHIxqVCwk34Zd7jEqriSPiBq4N+M4hHPyOhOQYnBupCQwgwE6iHHbWPQpX18Hu4HXVfQ==" src="https://github.githubassets.com/assets/5222-cafcc8852ca7.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-0KPr1fHNh0XrNfoQFV9QP/CoP23cBaiLkh8ko8ehOeZyS5Xwrz3jWm+wD1/qTsNf5Pg4jOyDj0tgjeDR4ENtNQ==" src="https://github.githubassets.com/assets/behaviors-d0a3ebd5f1cd.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-gy8qIM5ywfZwY9t64qGa3rDcqWJGKXayF+CsUt0owghpz2eqnNX2tMtSRRdOybIIwu6cScH/b8SkXvSHQt5qow==" src="https://github.githubassets.com/assets/7749-832f2a20ce72.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-XWCpyEQy0ukcAhCgvebb7RhB3Gl9ap6gzdKXsD2zOb099rINj1JJNqwQl3xCEzq4VQKz0OTVRe+2f9RiPrEBcQ==" src="https://github.githubassets.com/assets/notifications-global-5d60a9c84432.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-xyGHYwjeMuGHmOdgy9Kb/p7zpSxjrw197tH6c+PzJj3L9zUCmjXBRbPky6B3Dqc/dN0x6OPF7n2Uh5u5MdbVUw==" src="https://github.githubassets.com/assets/90-c721876308de.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-AYqt3h3e9yBPkTVipsLLUCU2qCv7M31EodfqWxo5UKYyx8iI44MniIvWI5K+skqivkk0Auq3QaWslerlSihYqA==" src="https://github.githubassets.com/assets/6813-018aadde1dde.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-fVWEYrwNiNqMDgK2qU/B+IumJZbvKseQoon/V//Dxcm9+btlS1AEfEWqogm9ZVQtDGEeu+fyazqJuSOxYsqSLA==" src="https://github.githubassets.com/assets/6637-7d558462bc0d.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-/QlUgO5cJKKqK71jHy3JgJbh7lu8OmQCyC9bRthe/2Oe6exWHKdR9a3il0Qz1DP+UM5BSGcdh0AF9woPn80kUg==" src="https://github.githubassets.com/assets/6791-fd095480ee5c.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-IIxK8FhcKILtaqpL41RZDRx2+5bMvqOMrZmaFwzJU4sy9OwoqEd1lP8ZCi1LrRAZBU2SkkHk2o1dr1Qsco7msg==" src="https://github.githubassets.com/assets/repositories-208c4af0585c.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-TW37x5st6o/HzJM1dpfCN2GZo5ymP18A5WVYawn9r50u67fyxJItX3wN+F2oQmZY1/K69yuqlXR3bmAPtka6Lw==" src="https://github.githubassets.com/assets/diffs-4d6dfbc79b2d.js"></script>
  

  <meta name="viewport" content="width=device-width">
  
  <title>mebjas.github.io/assets/research/exposure_fusion/ef.js at 37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2 · mebjas/mebjas.github.io · GitHub</title>
    <meta name="description" content="Repository for hosting my personal home page and blog. - mebjas.github.io/assets/research/exposure_fusion/ef.js at 37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2 · mebjas/mebjas.github.io">
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">
  <meta name="apple-itunes-app" content="app-id=1477376905" />
    <meta name="twitter:image:src" content="https://opengraph.githubassets.com/c6a966f949adb91ee84eac511b818deccbd86b6cb98a3f1ece8df462bb6038ce/mebjas/mebjas.github.io" /><meta name="twitter:site" content="@github" /><meta name="twitter:card" content="summary_large_image" /><meta name="twitter:title" content="mebjas.github.io/assets/research/exposure_fusion/ef.js at 37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2 · mebjas/mebjas.github.io" /><meta name="twitter:description" content="Repository for hosting my personal home page and blog. - mebjas.github.io/assets/research/exposure_fusion/ef.js at 37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2 · mebjas/mebjas.github.io" />
    <meta property="og:image" content="https://opengraph.githubassets.com/c6a966f949adb91ee84eac511b818deccbd86b6cb98a3f1ece8df462bb6038ce/mebjas/mebjas.github.io" /><meta property="og:image:alt" content="Repository for hosting my personal home page and blog. - mebjas.github.io/assets/research/exposure_fusion/ef.js at 37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2 · mebjas/mebjas.github.io" /><meta property="og:image:width" content="1200" /><meta property="og:image:height" content="600" /><meta property="og:site_name" content="GitHub" /><meta property="og:type" content="object" /><meta property="og:title" content="mebjas.github.io/assets/research/exposure_fusion/ef.js at 37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2 · mebjas/mebjas.github.io" /><meta property="og:url" content="https://github.com/mebjas/mebjas.github.io" /><meta property="og:description" content="Repository for hosting my personal home page and blog. - mebjas.github.io/assets/research/exposure_fusion/ef.js at 37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2 · mebjas/mebjas.github.io" />
    



    

  <link rel="assets" href="https://github.githubassets.com/">
  

  <meta name="request-id" content="0F10:5ED7:354699:58340F:6247D959" data-pjax-transient="true"/><meta name="html-safe-nonce" content="83532376a706c9eb55417b8fffe7fa0806ec21d9236b56f41282f3834a14b907" data-pjax-transient="true"/><meta name="visitor-payload" content="eyJyZWZlcnJlciI6Imh0dHA6Ly9naXRodWIuY29tL21lYmphcy9tZWJqYXMuZ2l0aHViLmlvL2Jsb2IvbWFzdGVyL2Fzc2V0cy9yZXNlYXJjaC9leHBvc3VyZV9mdXNpb24vZWYuanMiLCJyZXF1ZXN0X2lkIjoiMEYxMDo1RUQ3OjM1NDY5OTo1ODM0MEY6NjI0N0Q5NTkiLCJ2aXNpdG9yX2lkIjoiNjczODMzMjIxMzMzMjkyNDczOSIsInJlZ2lvbl9lZGdlIjoiaWFkIiwicmVnaW9uX3JlbmRlciI6ImlhZCJ9" data-pjax-transient="true"/><meta name="visitor-hmac" content="85df144422e6cdb823a3bb960d98b141aa3d42a883b2c1e23851074753ba35cd" data-pjax-transient="true"/>

    <meta name="hovercard-subject-tag" content="repository:220986749" data-pjax-transient>


  <meta name="github-keyboard-shortcuts" content="repository" data-pjax-transient="true" />

  

  <meta name="selected-link" value="repo_source" data-pjax-transient>

    <meta name="google-site-verification" content="c1kuD-K2HIVF635lypcsWPoD4kilo5-jA_wBFyT4uMY">
  <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
  <meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
  <meta name="google-site-verification" content="GXs5KoUUkNCoaAZn7wPN-t01Pywp9M3sEjnt_3_ZWPc">

<meta name="octolytics-url" content="https://collector.github.com/github/collect" />

  <meta name="analytics-location" content="/&lt;user-name&gt;/&lt;repo-name&gt;/blob/blame" data-pjax-transient="true" />

  




  

      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">



      <meta name="expected-hostname" content="github.com">


    <meta name="enabled-features" content="MARKETPLACE_PENDING_INSTALLATIONS">


  <meta http-equiv="x-pjax-version" content="0d69f823fc3c006453dc9d5d2512515c0bb0f722ac41cdf135f17a6c749c7cde" data-turbo-track="reload">
  <meta http-equiv="x-pjax-csp-version" content="fae078b7b0f21a3e87927a83cac351f9689d75ae7723ea091b3b1ae42747c273" data-turbo-track="reload">
  <meta http-equiv="x-pjax-css-version" content="0795d9e2979067ce2a2178ac7e69af171aee8dced9639aaea610ac98d56bd2f3" data-turbo-track="reload">
  <meta http-equiv="x-pjax-js-version" content="d427542ab58bdbba04db6daf7cc8705964093198a21a0675bf9a257fe166a43b" data-turbo-track="reload">
  

          <meta name="robots" content="noindex, nofollow" />

  <meta name="go-import" content="github.com/mebjas/mebjas.github.io git https://github.com/mebjas/mebjas.github.io.git">

  <meta name="octolytics-dimension-user_id" content="3007365" /><meta name="octolytics-dimension-user_login" content="mebjas" /><meta name="octolytics-dimension-repository_id" content="220986749" /><meta name="octolytics-dimension-repository_nwo" content="mebjas/mebjas.github.io" /><meta name="octolytics-dimension-repository_public" content="true" /><meta name="octolytics-dimension-repository_is_fork" content="false" /><meta name="octolytics-dimension-repository_network_root_id" content="220986749" /><meta name="octolytics-dimension-repository_network_root_nwo" content="mebjas/mebjas.github.io" />





  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <meta name="browser-optimizely-client-errors-url" content="https://api.github.com/_private/browser/optimizely_client/errors">

  <link rel="mask-icon" href="https://github.githubassets.com/pinned-octocat.svg" color="#000000">
  <link rel="alternate icon" class="js-site-favicon" type="image/png" href="https://github.githubassets.com/favicons/favicon.png">
  <link rel="icon" class="js-site-favicon" type="image/svg+xml" href="https://github.githubassets.com/favicons/favicon.svg">

<meta name="theme-color" content="#1e2327">
<meta name="color-scheme" content="light dark" />


  <link rel="manifest" href="/manifest.json" crossOrigin="use-credentials">

  </head>

  <body class="logged-out env-production page-responsive full-width" style="word-wrap: break-word;">
    

    <div class="position-relative js-header-wrapper ">
      <a href="#start-of-content" class="px-2 py-4 color-bg-accent-emphasis color-fg-on-emphasis show-on-focus js-skip-to-content">Skip to content</a>
      <span data-view-component="true" class="progress-pjax-loader js-pjax-loader-bar Progress position-fixed width-full">
    <span style="width: 0%;" data-view-component="true" class="Progress-item progress-pjax-loader-bar left-0 top-0 color-bg-accent-emphasis"></span>
</span>      
      


        

            <header class="Header-old header-logged-out js-details-container Details position-relative f4 py-2" role="banner">
  <div class="container-xl d-lg-flex flex-items-center p-responsive">
    <div class="d-flex flex-justify-between flex-items-center">
      <a class="mr-4 color-fg-inherit" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
        <svg height="32" aria-hidden="true" viewBox="0 0 16 16" version="1.1" width="32" data-view-component="true" class="octicon octicon-mark-github">
    <path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"></path>
</svg>
      </a>

        <div class="d-lg-none css-truncate css-truncate-target width-fit p-2">
          

        </div>

      <div class="d-flex flex-items-center">
            <a href="/signup?ref_cta=Sign+up&amp;ref_loc=header+logged+out&amp;ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E%2Fblob%2Fblame&amp;source=header-repo"
              class="d-inline-block d-lg-none f5 no-underline border color-border-default rounded-2 px-2 py-1 mr-3 mr-sm-5 color-fg-inherit"
              data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="2eddeabfd783b020114391e98ac368114bd8f90e2b59d67e5e14676d32146dcf"
            >
              Sign&nbsp;up
            </a>

        <button aria-label="Toggle navigation" aria-expanded="false" type="button" data-view-component="true" class="js-details-target btn-link d-lg-none mt-1 color-fg-inherit">  <svg aria-hidden="true" height="24" viewBox="0 0 16 16" version="1.1" width="24" data-view-component="true" class="octicon octicon-three-bars">
    <path fill-rule="evenodd" d="M1 2.75A.75.75 0 011.75 2h12.5a.75.75 0 110 1.5H1.75A.75.75 0 011 2.75zm0 5A.75.75 0 011.75 7h12.5a.75.75 0 110 1.5H1.75A.75.75 0 011 7.75zM1.75 12a.75.75 0 100 1.5h12.5a.75.75 0 100-1.5H1.75z"></path>
</svg>
</button>      </div>
    </div>

    <div class="HeaderMenu HeaderMenu--logged-out position-fixed top-0 right-0 bottom-0 height-fit position-lg-relative d-lg-flex flex-justify-between flex-items-center flex-auto">
      <div class="d-flex d-lg-none flex-justify-end border-bottom color-bg-subtle p-3">
        <button aria-label="Toggle navigation" aria-expanded="false" type="button" data-view-component="true" class="js-details-target btn-link">  <svg aria-hidden="true" height="24" viewBox="0 0 24 24" version="1.1" width="24" data-view-component="true" class="octicon octicon-x color-fg-muted">
    <path fill-rule="evenodd" d="M5.72 5.72a.75.75 0 011.06 0L12 10.94l5.22-5.22a.75.75 0 111.06 1.06L13.06 12l5.22 5.22a.75.75 0 11-1.06 1.06L12 13.06l-5.22 5.22a.75.75 0 01-1.06-1.06L10.94 12 5.72 6.78a.75.75 0 010-1.06z"></path>
</svg>
</button>      </div>

        <nav class="mt-0 px-3 px-lg-0 mb-5 mb-lg-0" aria-label="Global">
          <ul class="d-lg-flex list-style-none">
              <li class="mr-0 mr-lg-3 position-relative flex-wrap flex-justify-between flex-items-center border-bottom border-lg-bottom-0 d-block d-lg-flex flex-lg-nowrap flex-lg-items-center">
    <details class="HeaderMenu-details details-overlay details-reset width-full">
      <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap d-block d-lg-inline-block">
        Product
        <svg x="0" y="0" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-absolute position-lg-relative"><path d="M1,1l6.2,6L13,1"></path></svg>
      </summary>
      <div class="dropdown-menu flex-auto rounded px-0 mt-0 pb-4 p-lg-4 position-relative position-lg-absolute left-0 left-lg-n4">
        <ul class="list-style-none f5 pb-1">
              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--primary text-bold py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Features&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Features;&quot;}" href="/features">
      Features
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Mobile&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Mobile;&quot;}" href="/mobile">
      Mobile
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Actions&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Actions;&quot;}" href="/features/actions">
      Actions
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Codespaces&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Codespaces;&quot;}" href="/features/codespaces">
      Codespaces
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Packages&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Packages;&quot;}" href="/features/packages">
      Packages
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Security&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Security;&quot;}" href="/features/security">
      Security
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Code review&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Code review;&quot;}" href="/features/code-review">
      Code review
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Issues&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Issues;&quot;}" href="/features/issues">
      Issues
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Integrations&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Integrations;&quot;}" href="/features/integrations">
      Integrations
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--primary text-bold border-top pt-4 pb-2 mt-3" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to GitHub Sponsors&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:GitHub Sponsors;&quot;}" href="/sponsors">
      GitHub Sponsors
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--primary text-bold py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Customer stories&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Customer stories;&quot;}" href="/customer-stories">
      Customer stories
</a>  </li>

        </ul>
      </div>
    </details>
</li>


              <li class="mr-0 mr-lg-3 position-relative flex-wrap flex-justify-between flex-items-center border-bottom border-lg-bottom-0 d-block d-lg-flex flex-lg-nowrap flex-lg-items-center">
    <a class="HeaderMenu-link no-underline py-3 d-block d-lg-inline-block" data-analytics-event="{&quot;category&quot;:&quot;Header menu top item (logged out)&quot;,&quot;action&quot;:&quot;click to go to Team&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Team;&quot;}" href="/team">Team</a>
</li>

              <li class="mr-0 mr-lg-3 position-relative flex-wrap flex-justify-between flex-items-center border-bottom border-lg-bottom-0 d-block d-lg-flex flex-lg-nowrap flex-lg-items-center">
    <a class="HeaderMenu-link no-underline py-3 d-block d-lg-inline-block" data-analytics-event="{&quot;category&quot;:&quot;Header menu top item (logged out)&quot;,&quot;action&quot;:&quot;click to go to Enterprise&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Enterprise;&quot;}" href="/enterprise">Enterprise</a>
</li>


            <li class="mr-0 mr-lg-3 position-relative flex-wrap flex-justify-between flex-items-center border-bottom border-lg-bottom-0 d-block d-lg-flex flex-lg-nowrap flex-lg-items-center">
    <details class="HeaderMenu-details details-overlay details-reset width-full">
      <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap d-block d-lg-inline-block">
        Explore
        <svg x="0" y="0" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-absolute position-lg-relative"><path d="M1,1l6.2,6L13,1"></path></svg>
      </summary>
      <div class="dropdown-menu flex-auto rounded px-0 mt-0 pb-4 p-lg-4 position-relative position-lg-absolute left-0 left-lg-n4">
        <ul class="list-style-none f5 pb-1">
              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--primary text-bold py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Explore GitHub&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Explore GitHub;&quot;}" href="/explore">
      Explore GitHub
</a>  </li>

              <li class="color-fg-muted text-normal f6 text-mono mb-1 border-top pt-3 mt-3 mb-1">Learn and contribute</li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Topics&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Topics;&quot;}" href="/topics">
      Topics
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Collections&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Collections;&quot;}" href="/collections">
      Collections
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Trending&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Trending;&quot;}" href="/trending">
      Trending
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Learning Lab&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Learning Lab;&quot;}" href="https://lab.github.com/">
      Learning Lab
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Open source guides&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Open source guides;&quot;}" href="https://opensource.guide">
      Open source guides
</a>  </li>

              <li class="color-fg-muted text-normal f6 text-mono mb-1 border-top pt-3 mt-3 mb-1">Connect with others</li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to The ReadME Project&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:The ReadME Project;&quot;}" href="/readme">
      The ReadME Project
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Events&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Events;&quot;}" href="/events">
      Events
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Community forum&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Community forum;&quot;}" href="https://github.community">
      Community forum
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to GitHub Education&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:GitHub Education;&quot;}" href="https://education.github.com">
      GitHub Education
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to GitHub Stars program&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:GitHub Stars program;&quot;}" href="https://stars.github.com">
      GitHub Stars program
</a>  </li>

        </ul>
      </div>
    </details>
</li>


            <li class="mr-0 mr-lg-3 position-relative flex-wrap flex-justify-between flex-items-center border-bottom border-lg-bottom-0 d-block d-lg-flex flex-lg-nowrap flex-lg-items-center">
    <a class="HeaderMenu-link no-underline py-3 d-block d-lg-inline-block" data-analytics-event="{&quot;category&quot;:&quot;Header menu top item (logged out)&quot;,&quot;action&quot;:&quot;click to go to Marketplace&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Marketplace;&quot;}" href="/marketplace">Marketplace</a>
</li>


            <li class="mr-0 mr-lg-3 position-relative flex-wrap flex-justify-between flex-items-center border-bottom border-lg-bottom-0 d-block d-lg-flex flex-lg-nowrap flex-lg-items-center">
    <details class="HeaderMenu-details details-overlay details-reset width-full">
      <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap d-block d-lg-inline-block">
        Pricing
        <svg x="0" y="0" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-absolute position-lg-relative"><path d="M1,1l6.2,6L13,1"></path></svg>
      </summary>
      <div class="dropdown-menu flex-auto rounded px-0 mt-0 pb-4 p-lg-4 position-relative position-lg-absolute left-0 left-lg-n4">
        <ul class="list-style-none f5 pb-1">
              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--primary text-bold py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Pricing&quot;,&quot;action&quot;:&quot;click to go to Plans&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Plans;&quot;}" href="/pricing">
      Plans
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Pricing&quot;,&quot;action&quot;:&quot;click to go to Compare plans&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Compare plans;&quot;}" href="/pricing#compare-features">
      Compare plans
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Pricing&quot;,&quot;action&quot;:&quot;click to go to Contact Sales&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Contact Sales;&quot;}" href="https://github.com/enterprise/contact">
      Contact Sales
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--primary text-bold border-top pt-4 pb-2 mt-3" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Pricing&quot;,&quot;action&quot;:&quot;click to go to Education&quot;,&quot;label&quot;:&quot;ref_page:/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js;ref_cta:Education;&quot;}" href="https://education.github.com">
      Education
</a>  </li>

        </ul>
      </div>
    </details>
</li>

          </ul>
        </nav>

      <div class="d-lg-flex flex-items-center px-3 px-lg-0 text-center text-lg-left">
          <div class="d-lg-flex min-width-0 mb-3 mb-lg-0">
            



<div class="header-search flex-auto js-site-search position-relative flex-self-stretch flex-md-self-auto mb-3 mb-md-0 mr-0 mr-md-3 scoped-search site-scoped-search js-jump-to"
>
  <div class="position-relative">
    <!-- '"` --><!-- </textarea></xmp> --></option></form><form class="js-site-search-form" role="search" aria-label="Site" data-scope-type="Repository" data-scope-id="220986749" data-scoped-search-url="/mebjas/mebjas.github.io/search" data-owner-scoped-search-url="/users/mebjas/search" data-unscoped-search-url="/search" data-turbo="false" action="/mebjas/mebjas.github.io/search" accept-charset="UTF-8" method="get">
      <label class="form-control input-sm header-search-wrapper p-0 js-chromeless-input-container header-search-wrapper-jump-to position-relative d-flex flex-justify-between flex-items-center">
        <input type="text"
          class="form-control input-sm header-search-input jump-to-field js-jump-to-field js-site-search-focus js-site-search-field is-clearable"
          data-hotkey=s,/
          name="q"
          data-test-selector="nav-search-input"
          placeholder="Search"
          data-unscoped-placeholder="Search GitHub"
          data-scoped-placeholder="Search"
          autocapitalize="off"
          role="combobox"
          aria-haspopup="listbox"
          aria-expanded="false"
          aria-autocomplete="list"
          aria-controls="jump-to-results"
          aria-label="Search"
          data-jump-to-suggestions-path="/_graphql/GetSuggestedNavigationDestinations"
          spellcheck="false"
          autocomplete="off"
        >
        <input type="hidden" data-csrf="true" class="js-data-jump-to-suggestions-path-csrf" value="pG9m4gG7vAj2Tv7Sdyqt1r/iPxC8YH4aE7Kl0ISHAgB0SAXy8Fj49VMxq9oJBUAqdM/kdZjWfMEYlvlEmKGSQQ==" />
        <input type="hidden" class="js-site-search-type-field" name="type" >
            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="20" aria-hidden="true" class="mr-1 header-search-key-slash"><path fill="none" stroke="#979A9C" opacity=".4" d="M3.5.5h12c1.7 0 3 1.3 3 3v13c0 1.7-1.3 3-3 3h-12c-1.7 0-3-1.3-3-3v-13c0-1.7 1.3-3 3-3z"></path><path fill="#979A9C" d="M11.8 6L8 15.1h-.9L10.8 6h1z"></path></svg>


          <div class="Box position-absolute overflow-hidden d-none jump-to-suggestions js-jump-to-suggestions-container">
            
<ul class="d-none js-jump-to-suggestions-template-container">
  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-suggestion" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="" data-item-type="suggestion">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg title="Repository" aria-label="Repository" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo js-jump-to-octicon-repo d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M2 2.5A2.5 2.5 0 014.5 0h8.75a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75h-2.5a.75.75 0 110-1.5h1.75v-2h-8a1 1 0 00-.714 1.7.75.75 0 01-1.072 1.05A2.495 2.495 0 012 11.5v-9zm10.5-1V9h-8c-.356 0-.694.074-1 .208V2.5a1 1 0 011-1h8zM5 12.25v3.25a.25.25 0 00.4.2l1.45-1.087a.25.25 0 01.3 0L8.6 15.7a.25.25 0 00.4-.2v-3.25a.25.25 0 00-.25-.25h-3.5a.25.25 0 00-.25.25z"></path>
</svg>
      <svg title="Project" aria-label="Project" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-project js-jump-to-octicon-project d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M1.75 0A1.75 1.75 0 000 1.75v12.5C0 15.216.784 16 1.75 16h12.5A1.75 1.75 0 0016 14.25V1.75A1.75 1.75 0 0014.25 0H1.75zM1.5 1.75a.25.25 0 01.25-.25h12.5a.25.25 0 01.25.25v12.5a.25.25 0 01-.25.25H1.75a.25.25 0 01-.25-.25V1.75zM11.75 3a.75.75 0 00-.75.75v7.5a.75.75 0 001.5 0v-7.5a.75.75 0 00-.75-.75zm-8.25.75a.75.75 0 011.5 0v5.5a.75.75 0 01-1.5 0v-5.5zM8 3a.75.75 0 00-.75.75v3.5a.75.75 0 001.5 0v-3.5A.75.75 0 008 3z"></path>
</svg>
      <svg title="Search" aria-label="Search" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search js-jump-to-octicon-search d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M11.5 7a4.499 4.499 0 11-8.998 0A4.499 4.499 0 0111.5 7zm-.82 4.74a6 6 0 111.06-1.06l3.04 3.04a.75.75 0 11-1.06 1.06l-3.04-3.04z"></path>
</svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>

</ul>

<ul class="d-none js-jump-to-no-results-template-container">
  <li class="d-flex flex-justify-center flex-items-center f5 d-none js-jump-to-suggestion p-2">
    <span class="color-fg-muted">No suggested jump to results</span>
  </li>
</ul>

<ul id="jump-to-results" role="listbox" class="p-0 m-0 js-navigation-container jump-to-suggestions-results-container js-jump-to-suggestions-results-container">
  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-scoped-search d-none" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="" data-item-type="scoped_search">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg title="Repository" aria-label="Repository" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo js-jump-to-octicon-repo d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M2 2.5A2.5 2.5 0 014.5 0h8.75a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75h-2.5a.75.75 0 110-1.5h1.75v-2h-8a1 1 0 00-.714 1.7.75.75 0 01-1.072 1.05A2.495 2.495 0 012 11.5v-9zm10.5-1V9h-8c-.356 0-.694.074-1 .208V2.5a1 1 0 011-1h8zM5 12.25v3.25a.25.25 0 00.4.2l1.45-1.087a.25.25 0 01.3 0L8.6 15.7a.25.25 0 00.4-.2v-3.25a.25.25 0 00-.25-.25h-3.5a.25.25 0 00-.25.25z"></path>
</svg>
      <svg title="Project" aria-label="Project" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-project js-jump-to-octicon-project d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M1.75 0A1.75 1.75 0 000 1.75v12.5C0 15.216.784 16 1.75 16h12.5A1.75 1.75 0 0016 14.25V1.75A1.75 1.75 0 0014.25 0H1.75zM1.5 1.75a.25.25 0 01.25-.25h12.5a.25.25 0 01.25.25v12.5a.25.25 0 01-.25.25H1.75a.25.25 0 01-.25-.25V1.75zM11.75 3a.75.75 0 00-.75.75v7.5a.75.75 0 001.5 0v-7.5a.75.75 0 00-.75-.75zm-8.25.75a.75.75 0 011.5 0v5.5a.75.75 0 01-1.5 0v-5.5zM8 3a.75.75 0 00-.75.75v3.5a.75.75 0 001.5 0v-3.5A.75.75 0 008 3z"></path>
</svg>
      <svg title="Search" aria-label="Search" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search js-jump-to-octicon-search d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M11.5 7a4.499 4.499 0 11-8.998 0A4.499 4.499 0 0111.5 7zm-.82 4.74a6 6 0 111.06-1.06l3.04 3.04a.75.75 0 11-1.06 1.06l-3.04-3.04z"></path>
</svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>

  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-owner-scoped-search d-none" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="" data-item-type="owner_scoped_search">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg title="Repository" aria-label="Repository" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo js-jump-to-octicon-repo d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M2 2.5A2.5 2.5 0 014.5 0h8.75a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75h-2.5a.75.75 0 110-1.5h1.75v-2h-8a1 1 0 00-.714 1.7.75.75 0 01-1.072 1.05A2.495 2.495 0 012 11.5v-9zm10.5-1V9h-8c-.356 0-.694.074-1 .208V2.5a1 1 0 011-1h8zM5 12.25v3.25a.25.25 0 00.4.2l1.45-1.087a.25.25 0 01.3 0L8.6 15.7a.25.25 0 00.4-.2v-3.25a.25.25 0 00-.25-.25h-3.5a.25.25 0 00-.25.25z"></path>
</svg>
      <svg title="Project" aria-label="Project" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-project js-jump-to-octicon-project d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M1.75 0A1.75 1.75 0 000 1.75v12.5C0 15.216.784 16 1.75 16h12.5A1.75 1.75 0 0016 14.25V1.75A1.75 1.75 0 0014.25 0H1.75zM1.5 1.75a.25.25 0 01.25-.25h12.5a.25.25 0 01.25.25v12.5a.25.25 0 01-.25.25H1.75a.25.25 0 01-.25-.25V1.75zM11.75 3a.75.75 0 00-.75.75v7.5a.75.75 0 001.5 0v-7.5a.75.75 0 00-.75-.75zm-8.25.75a.75.75 0 011.5 0v5.5a.75.75 0 01-1.5 0v-5.5zM8 3a.75.75 0 00-.75.75v3.5a.75.75 0 001.5 0v-3.5A.75.75 0 008 3z"></path>
</svg>
      <svg title="Search" aria-label="Search" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search js-jump-to-octicon-search d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M11.5 7a4.499 4.499 0 11-8.998 0A4.499 4.499 0 0111.5 7zm-.82 4.74a6 6 0 111.06-1.06l3.04 3.04a.75.75 0 11-1.06 1.06l-3.04-3.04z"></path>
</svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this user">
        In this user
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>

  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-global-search d-none" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="" data-item-type="global_search">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg title="Repository" aria-label="Repository" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo js-jump-to-octicon-repo d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M2 2.5A2.5 2.5 0 014.5 0h8.75a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75h-2.5a.75.75 0 110-1.5h1.75v-2h-8a1 1 0 00-.714 1.7.75.75 0 01-1.072 1.05A2.495 2.495 0 012 11.5v-9zm10.5-1V9h-8c-.356 0-.694.074-1 .208V2.5a1 1 0 011-1h8zM5 12.25v3.25a.25.25 0 00.4.2l1.45-1.087a.25.25 0 01.3 0L8.6 15.7a.25.25 0 00.4-.2v-3.25a.25.25 0 00-.25-.25h-3.5a.25.25 0 00-.25.25z"></path>
</svg>
      <svg title="Project" aria-label="Project" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-project js-jump-to-octicon-project d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M1.75 0A1.75 1.75 0 000 1.75v12.5C0 15.216.784 16 1.75 16h12.5A1.75 1.75 0 0016 14.25V1.75A1.75 1.75 0 0014.25 0H1.75zM1.5 1.75a.25.25 0 01.25-.25h12.5a.25.25 0 01.25.25v12.5a.25.25 0 01-.25.25H1.75a.25.25 0 01-.25-.25V1.75zM11.75 3a.75.75 0 00-.75.75v7.5a.75.75 0 001.5 0v-7.5a.75.75 0 00-.75-.75zm-8.25.75a.75.75 0 011.5 0v5.5a.75.75 0 01-1.5 0v-5.5zM8 3a.75.75 0 00-.75.75v3.5a.75.75 0 001.5 0v-3.5A.75.75 0 008 3z"></path>
</svg>
      <svg title="Search" aria-label="Search" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search js-jump-to-octicon-search d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M11.5 7a4.499 4.499 0 11-8.998 0A4.499 4.499 0 0111.5 7zm-.82 4.74a6 6 0 111.06-1.06l3.04 3.04a.75.75 0 11-1.06 1.06l-3.04-3.04z"></path>
</svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>


</ul>

          </div>
      </label>
</form>  </div>
</div>

          </div>

        <div class="position-relative mr-3 mb-4 mb-lg-0 d-inline-block">
          <a href="/login?return_to=https%3A%2F%2Fgithub.com%2Fmebjas%2Fmebjas.github.io%2Fblame%2F37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2%2Fassets%2Fresearch%2Fexposure_fusion%2Fef.js"
            class="HeaderMenu-link flex-shrink-0 no-underline"
            data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header menu&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="d68927f783b23743808aa875d34c31ae5f99b57b8a2243655c9f130a9e639cd1"
            data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">
            Sign in
          </a>
        </div>

          <a href="/signup?ref_cta=Sign+up&amp;ref_loc=header+logged+out&amp;ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E%2Fblob%2Fblame&amp;source=header-repo&amp;source_repo=mebjas%2Fmebjas.github.io"
            class="HeaderMenu-link flex-shrink-0 d-inline-block no-underline border color-border-default rounded px-2 py-1"
            data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header menu&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="d68927f783b23743808aa875d34c31ae5f99b57b8a2243655c9f130a9e639cd1"
            data-analytics-event="{&quot;category&quot;:&quot;Sign up&quot;,&quot;action&quot;:&quot;click to sign up for account&quot;,&quot;label&quot;:&quot;ref_page:/&lt;user-name&gt;/&lt;repo-name&gt;/blob/blame;ref_cta:Sign up;ref_loc:header logged out&quot;}"
          >
            Sign up
          </a>
      </div>
    </div>
  </div>
</header>

    </div>

  <div id="start-of-content" class="show-on-focus"></div>







    <div data-pjax-replace id="js-flash-container">


  <template class="js-flash-template">
    <div class="flash flash-full  {{ className }}">
  <div class="px-2" >
    <button class="flash-close js-flash-close" type="button" aria-label="Dismiss this message">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
    </button>
    
      <div>{{ message }}</div>

  </div>
</div>
  </template>
</div>


    

  <include-fragment class="js-notification-shelf-include-fragment" data-base-src="https://github.com/notifications/beta/shelf"></include-fragment>





  <div
    class="application-main "
    data-commit-hovercards-enabled
    data-discussion-hovercards-enabled
    data-issue-and-pr-hovercards-enabled
  >
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode" class="">
    <main id="js-repo-pjax-container" data-pjax-container >
      
    






  <div id="repository-container-header" class="pt-3 hide-full-screen" style="background-color: var(--color-page-header-bg);" data-pjax-replace>

      <div class="d-flex mb-3 px-3 px-md-4 px-lg-5">

        <div class="flex-auto min-width-0 width-fit mr-3">
            <h1 class=" d-flex flex-wrap flex-items-center wb-break-word f3 text-normal">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo color-fg-muted mr-2">
    <path fill-rule="evenodd" d="M2 2.5A2.5 2.5 0 014.5 0h8.75a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75h-2.5a.75.75 0 110-1.5h1.75v-2h-8a1 1 0 00-.714 1.7.75.75 0 01-1.072 1.05A2.495 2.495 0 012 11.5v-9zm10.5-1V9h-8c-.356 0-.694.074-1 .208V2.5a1 1 0 011-1h8zM5 12.25v3.25a.25.25 0 00.4.2l1.45-1.087a.25.25 0 01.3 0L8.6 15.7a.25.25 0 00.4-.2v-3.25a.25.25 0 00-.25-.25h-3.5a.25.25 0 00-.25.25z"></path>
</svg>
  <span class="author flex-self-stretch" itemprop="author">
    <a class="url fn" rel="author" data-hovercard-type="user" data-hovercard-url="/users/mebjas/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mebjas">mebjas</a>
  </span>
  <span class="mx-1 flex-self-stretch color-fg-muted">/</span>
  <strong itemprop="name" class="mr-2 flex-self-stretch">
    <a data-pjax="#repo-content-pjax-container" href="/mebjas/mebjas.github.io">mebjas.github.io</a>
  </strong>

  <span></span><span class="Label Label--secondary v-align-middle mr-1">Public</span>
</h1>

        </div>

          <ul class="pagehead-actions flex-shrink-0 d-none d-md-inline" style="padding: 2px 0;">

  

  <li>
      <a href="/login?return_to=%2Fmebjas%2Fmebjas.github.io" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;notification subscription menu watch&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="51d81c9b76460564c63e33ac3b23b7455a29bfd65326f73645967d390b569ac6" aria-label="You must be signed in to change notification settings" data-view-component="true" class="tooltipped tooltipped-s btn-sm btn">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-bell mr-2">
    <path d="M8 16a2 2 0 001.985-1.75c.017-.137-.097-.25-.235-.25h-3.5c-.138 0-.252.113-.235.25A2 2 0 008 16z"></path><path fill-rule="evenodd" d="M8 1.5A3.5 3.5 0 004.5 5v2.947c0 .346-.102.683-.294.97l-1.703 2.556a.018.018 0 00-.003.01l.001.006c0 .002.002.004.004.006a.017.017 0 00.006.004l.007.001h10.964l.007-.001a.016.016 0 00.006-.004.016.016 0 00.004-.006l.001-.007a.017.017 0 00-.003-.01l-1.703-2.554a1.75 1.75 0 01-.294-.97V5A3.5 3.5 0 008 1.5zM3 5a5 5 0 0110 0v2.947c0 .05.015.098.042.139l1.703 2.555A1.518 1.518 0 0113.482 13H2.518a1.518 1.518 0 01-1.263-2.36l1.703-2.554A.25.25 0 003 7.947V5z"></path>
</svg>Notifications
</a>
  </li>

  <li>
        <a href="/login?return_to=%2Fmebjas%2Fmebjas.github.io" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;repo details fork button&quot;,&quot;repository_id&quot;:220986749,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="bc9b7b39a8888ec81517415a3962a632fc48ef0fd2e83821c47873f3703ed507" aria-label="You must be signed in to fork a repository" data-view-component="true" class="tooltipped tooltipped-s btn-sm btn">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo-forked mr-2">
    <path fill-rule="evenodd" d="M5 3.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm0 2.122a2.25 2.25 0 10-1.5 0v.878A2.25 2.25 0 005.75 8.5h1.5v2.128a2.251 2.251 0 101.5 0V8.5h1.5a2.25 2.25 0 002.25-2.25v-.878a2.25 2.25 0 10-1.5 0v.878a.75.75 0 01-.75.75h-4.5A.75.75 0 015 6.25v-.878zm3.75 7.378a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm3-8.75a.75.75 0 100-1.5.75.75 0 000 1.5z"></path>
</svg>Fork
    <span id="repo-network-counter" data-pjax-replace="true" title="3" data-view-component="true" class="Counter">3</span>
</a>
  </li>

  <li>
        <div data-view-component="true" class="BtnGroup d-flex">
      <a href="/login?return_to=%2Fmebjas%2Fmebjas.github.io" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;star button&quot;,&quot;repository_id&quot;:220986749,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="481733a335d970f3b5341ffe18489e4d7eee14ce8c73e0447f8173c9d104518f" aria-label="You must be signed in to star a repository" data-view-component="true" class="tooltipped tooltipped-s btn-sm btn BtnGroup-item">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-star v-align-text-bottom d-inline-block mr-2">
    <path fill-rule="evenodd" d="M8 .25a.75.75 0 01.673.418l1.882 3.815 4.21.612a.75.75 0 01.416 1.279l-3.046 2.97.719 4.192a.75.75 0 01-1.088.791L8 12.347l-3.766 1.98a.75.75 0 01-1.088-.79l.72-4.194L.818 6.374a.75.75 0 01.416-1.28l4.21-.611L7.327.668A.75.75 0 018 .25zm0 2.445L6.615 5.5a.75.75 0 01-.564.41l-3.097.45 2.24 2.184a.75.75 0 01.216.664l-.528 3.084 2.769-1.456a.75.75 0 01.698 0l2.77 1.456-.53-3.084a.75.75 0 01.216-.664l2.24-2.183-3.096-.45a.75.75 0 01-.564-.41L8 2.694v.001z"></path>
</svg><span data-view-component="true" class="d-inline">
          Star
</span>          <span id="repo-stars-counter-star" aria-label="7 users starred this repository" data-singular-suffix="user starred this repository" data-plural-suffix="users starred this repository" data-pjax-replace="true" title="7" data-view-component="true" class="Counter js-social-count">7</span>
</a>      <button disabled="disabled" aria-label="You must be signed in to add this repository to a list" type="button" data-view-component="true" class="btn-sm btn BtnGroup-item px-2">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-triangle-down">
    <path d="M4.427 7.427l3.396 3.396a.25.25 0 00.354 0l3.396-3.396A.25.25 0 0011.396 7H4.604a.25.25 0 00-.177.427z"></path>
</svg>
</button></div>
  </li>

  

</ul>

      </div>

      <div id="responsive-meta-container" data-pjax-replace>
</div>


        
<nav data-pjax="#js-repo-pjax-container" aria-label="Repository" data-view-component="true" class="js-repo-nav js-sidenav-container-pjax js-responsive-underlinenav overflow-hidden UnderlineNav px-3 px-md-4 px-lg-5">

  <ul data-view-component="true" class="UnderlineNav-body list-style-none">
      <li data-view-component="true" class="d-inline-flex">
  <a id="code-tab" href="/mebjas/mebjas.github.io" data-tab-item="i0code-tab" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages repo_deployments /mebjas/mebjas.github.io" data-pjax="#repo-content-pjax-container" data-hotkey="g c" data-ga-click="Repository, Navigation click, Code tab" aria-current="page" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item selected">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M4.72 3.22a.75.75 0 011.06 1.06L2.06 8l3.72 3.72a.75.75 0 11-1.06 1.06L.47 8.53a.75.75 0 010-1.06l4.25-4.25zm6.56 0a.75.75 0 10-1.06 1.06L13.94 8l-3.72 3.72a.75.75 0 101.06 1.06l4.25-4.25a.75.75 0 000-1.06l-4.25-4.25z"></path>
</svg>
          <span data-content="Code">Code</span>
            <span id="code-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="issues-tab" href="/mebjas/mebjas.github.io/issues" data-tab-item="i1issues-tab" data-selected-links="repo_issues repo_labels repo_milestones /mebjas/mebjas.github.io/issues" data-pjax="#repo-content-pjax-container" data-hotkey="g i" data-ga-click="Repository, Navigation click, Issues tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened UnderlineNav-octicon d-none d-sm-inline">
    <path d="M8 9.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"></path><path fill-rule="evenodd" d="M8 0a8 8 0 100 16A8 8 0 008 0zM1.5 8a6.5 6.5 0 1113 0 6.5 6.5 0 01-13 0z"></path>
</svg>
          <span data-content="Issues">Issues</span>
            <span id="issues-repo-tab-count" data-pjax-replace="" title="19" data-view-component="true" class="Counter">19</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="pull-requests-tab" href="/mebjas/mebjas.github.io/pulls" data-tab-item="i2pull-requests-tab" data-selected-links="repo_pulls checks /mebjas/mebjas.github.io/pulls" data-pjax="#repo-content-pjax-container" data-hotkey="g p" data-ga-click="Repository, Navigation click, Pull requests tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-pull-request UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M7.177 3.073L9.573.677A.25.25 0 0110 .854v4.792a.25.25 0 01-.427.177L7.177 3.427a.25.25 0 010-.354zM3.75 2.5a.75.75 0 100 1.5.75.75 0 000-1.5zm-2.25.75a2.25 2.25 0 113 2.122v5.256a2.251 2.251 0 11-1.5 0V5.372A2.25 2.25 0 011.5 3.25zM11 2.5h-1V4h1a1 1 0 011 1v5.628a2.251 2.251 0 101.5 0V5A2.5 2.5 0 0011 2.5zm1 10.25a.75.75 0 111.5 0 .75.75 0 01-1.5 0zM3.75 12a.75.75 0 100 1.5.75.75 0 000-1.5z"></path>
</svg>
          <span data-content="Pull requests">Pull requests</span>
            <span id="pull-requests-repo-tab-count" data-pjax-replace="" title="0" hidden="hidden" data-view-component="true" class="Counter">0</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="discussions-tab" href="/mebjas/mebjas.github.io/discussions" data-tab-item="i3discussions-tab" data-selected-links="repo_discussions /mebjas/mebjas.github.io/discussions" data-pjax="#repo-content-pjax-container" data-hotkey="g g" data-ga-click="Repository, Navigation click, Discussions tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-comment-discussion UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M1.5 2.75a.25.25 0 01.25-.25h8.5a.25.25 0 01.25.25v5.5a.25.25 0 01-.25.25h-3.5a.75.75 0 00-.53.22L3.5 11.44V9.25a.75.75 0 00-.75-.75h-1a.25.25 0 01-.25-.25v-5.5zM1.75 1A1.75 1.75 0 000 2.75v5.5C0 9.216.784 10 1.75 10H2v1.543a1.457 1.457 0 002.487 1.03L7.061 10h3.189A1.75 1.75 0 0012 8.25v-5.5A1.75 1.75 0 0010.25 1h-8.5zM14.5 4.75a.25.25 0 00-.25-.25h-.5a.75.75 0 110-1.5h.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0114.25 12H14v1.543a1.457 1.457 0 01-2.487 1.03L9.22 12.28a.75.75 0 111.06-1.06l2.22 2.22v-2.19a.75.75 0 01.75-.75h1a.25.25 0 00.25-.25v-5.5z"></path>
</svg>
          <span data-content="Discussions">Discussions</span>
            <span id="discussions-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="actions-tab" href="/mebjas/mebjas.github.io/actions" data-tab-item="i4actions-tab" data-selected-links="repo_actions /mebjas/mebjas.github.io/actions" data-pjax="#repo-content-pjax-container" data-hotkey="g a" data-analytics-event="{&quot;category&quot;:&quot;Actions&quot;,&quot;action&quot;:&quot;clicked&quot;,&quot;label&quot;:&quot;ref_cta:Actions;ref_loc:navigation_helper&quot;}" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-play UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M1.5 8a6.5 6.5 0 1113 0 6.5 6.5 0 01-13 0zM8 0a8 8 0 100 16A8 8 0 008 0zM6.379 5.227A.25.25 0 006 5.442v5.117a.25.25 0 00.379.214l4.264-2.559a.25.25 0 000-.428L6.379 5.227z"></path>
</svg>
          <span data-content="Actions">Actions</span>
            <span id="actions-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="projects-tab" href="/mebjas/mebjas.github.io/projects?type=beta" data-tab-item="i5projects-tab" data-selected-links="repo_projects new_repo_project repo_project /mebjas/mebjas.github.io/projects?type=beta" data-pjax="#repo-content-pjax-container" data-hotkey="g b" data-ga-click="Repository, Navigation click, Projects tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-table UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v3.585a.746.746 0 010 .83v8.085A1.75 1.75 0 0114.25 16H6.309a.748.748 0 01-1.118 0H1.75A1.75 1.75 0 010 14.25V6.165a.746.746 0 010-.83V1.75zM1.5 6.5v7.75c0 .138.112.25.25.25H5v-8H1.5zM5 5H1.5V1.75a.25.25 0 01.25-.25H5V5zm1.5 1.5v8h7.75a.25.25 0 00.25-.25V6.5h-8zm8-1.5h-8V1.5h7.75a.25.25 0 01.25.25V5z"></path>
</svg>
          <span data-content="Projects">Projects</span>
            <span id="projects-repo-tab-count" data-pjax-replace="" title="1" data-view-component="true" class="Counter">1</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="wiki-tab" href="/mebjas/mebjas.github.io/wiki" data-tab-item="i6wiki-tab" data-selected-links="repo_wiki /mebjas/mebjas.github.io/wiki" data-pjax="#repo-content-pjax-container" data-hotkey="g w" data-ga-click="Repository, Navigation click, Wikis tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-book UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M0 1.75A.75.75 0 01.75 1h4.253c1.227 0 2.317.59 3 1.501A3.744 3.744 0 0111.006 1h4.245a.75.75 0 01.75.75v10.5a.75.75 0 01-.75.75h-4.507a2.25 2.25 0 00-1.591.659l-.622.621a.75.75 0 01-1.06 0l-.622-.621A2.25 2.25 0 005.258 13H.75a.75.75 0 01-.75-.75V1.75zm8.755 3a2.25 2.25 0 012.25-2.25H14.5v9h-3.757c-.71 0-1.4.201-1.992.572l.004-7.322zm-1.504 7.324l.004-5.073-.002-2.253A2.25 2.25 0 005.003 2.5H1.5v9h3.757a3.75 3.75 0 011.994.574z"></path>
</svg>
          <span data-content="Wiki">Wiki</span>
            <span id="wiki-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="security-tab" href="/mebjas/mebjas.github.io/security" data-tab-item="i7security-tab" data-selected-links="security overview alerts policy token_scanning code_scanning /mebjas/mebjas.github.io/security" data-pjax="#repo-content-pjax-container" data-hotkey="g s" data-ga-click="Repository, Navigation click, Security tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-shield UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M7.467.133a1.75 1.75 0 011.066 0l5.25 1.68A1.75 1.75 0 0115 3.48V7c0 1.566-.32 3.182-1.303 4.682-.983 1.498-2.585 2.813-5.032 3.855a1.7 1.7 0 01-1.33 0c-2.447-1.042-4.049-2.357-5.032-3.855C1.32 10.182 1 8.566 1 7V3.48a1.75 1.75 0 011.217-1.667l5.25-1.68zm.61 1.429a.25.25 0 00-.153 0l-5.25 1.68a.25.25 0 00-.174.238V7c0 1.358.275 2.666 1.057 3.86.784 1.194 2.121 2.34 4.366 3.297a.2.2 0 00.154 0c2.245-.956 3.582-2.104 4.366-3.298C13.225 9.666 13.5 8.36 13.5 7V3.48a.25.25 0 00-.174-.237l-5.25-1.68zM9 10.5a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.75a.75.75 0 10-1.5 0v3a.75.75 0 001.5 0v-3z"></path>
</svg>
          <span data-content="Security">Security</span>
            <include-fragment src="/mebjas/mebjas.github.io/security/overall-count" accept="text/fragment+html"></include-fragment>

    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="insights-tab" href="/mebjas/mebjas.github.io/pulse" data-tab-item="i8insights-tab" data-selected-links="repo_graphs repo_contributors dependency_graph dependabot_updates pulse people community /mebjas/mebjas.github.io/pulse" data-pjax="#repo-content-pjax-container" data-ga-click="Repository, Navigation click, Insights tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-graph UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M1.5 1.75a.75.75 0 00-1.5 0v12.5c0 .414.336.75.75.75h14.5a.75.75 0 000-1.5H1.5V1.75zm14.28 2.53a.75.75 0 00-1.06-1.06L10 7.94 7.53 5.47a.75.75 0 00-1.06 0L3.22 8.72a.75.75 0 001.06 1.06L7 7.06l2.47 2.47a.75.75 0 001.06 0l5.25-5.25z"></path>
</svg>
          <span data-content="Insights">Insights</span>
            <span id="insights-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
</ul>
    <div style="visibility:hidden;" data-view-component="true" class="UnderlineNav-actions js-responsive-underlinenav-overflow position-absolute pr-3 pr-md-4 pr-lg-5 right-0">      <details data-view-component="true" class="details-overlay details-reset position-relative">
  <summary role="button" data-view-component="true">          <div class="UnderlineNav-item mr-0 border-0">
            <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-kebab-horizontal">
    <path d="M8 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM1.5 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm13 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"></path>
</svg>
            <span class="sr-only">More</span>
          </div>
</summary>
  <div data-view-component="true">          <details-menu role="menu" data-view-component="true" class="dropdown-menu dropdown-menu-sw">
  
            <ul>
                <li data-menu-item="i0code-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item selected dropdown-item" aria-current="page" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages repo_deployments /mebjas/mebjas.github.io" href="/mebjas/mebjas.github.io">
                    Code
</a>                </li>
                <li data-menu-item="i1issues-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_issues repo_labels repo_milestones /mebjas/mebjas.github.io/issues" href="/mebjas/mebjas.github.io/issues">
                    Issues
</a>                </li>
                <li data-menu-item="i2pull-requests-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_pulls checks /mebjas/mebjas.github.io/pulls" href="/mebjas/mebjas.github.io/pulls">
                    Pull requests
</a>                </li>
                <li data-menu-item="i3discussions-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_discussions /mebjas/mebjas.github.io/discussions" href="/mebjas/mebjas.github.io/discussions">
                    Discussions
</a>                </li>
                <li data-menu-item="i4actions-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_actions /mebjas/mebjas.github.io/actions" href="/mebjas/mebjas.github.io/actions">
                    Actions
</a>                </li>
                <li data-menu-item="i5projects-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_projects new_repo_project repo_project /mebjas/mebjas.github.io/projects?type=beta" href="/mebjas/mebjas.github.io/projects?type=beta">
                    Projects
</a>                </li>
                <li data-menu-item="i6wiki-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_wiki /mebjas/mebjas.github.io/wiki" href="/mebjas/mebjas.github.io/wiki">
                    Wiki
</a>                </li>
                <li data-menu-item="i7security-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="security overview alerts policy token_scanning code_scanning /mebjas/mebjas.github.io/security" href="/mebjas/mebjas.github.io/security">
                    Security
</a>                </li>
                <li data-menu-item="i8insights-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_graphs repo_contributors dependency_graph dependabot_updates pulse people community /mebjas/mebjas.github.io/pulse" href="/mebjas/mebjas.github.io/pulse">
                    Insights
</a>                </li>
            </ul>

</details-menu></div>
</details></div>
</nav>
  </div>



<div id="repo-content-pjax-container" class="repository-content " >
  
  


  
      
<div class="clearfix container-xl px-3 px-md-4 px-lg-5 mt-4">

  
<div class="wants-full-width-container"></div>

<a class="d-none js-permalink-shortcut" data-hotkey="y" href="/mebjas/mebjas.github.io/blame/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js">Permalink</a>

<div class="breadcrumb css-truncate blame-breadcrumb">
  <span id="blob-path" class="css-truncate-target"><span class="js-repo-root text-bold"><span class="js-path-segment d-inline-block wb-break-all"><a data-pjax="true" rel="nofollow" href="/mebjas/mebjas.github.io/tree/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2"><span>mebjas.github.io</span></a></span></span><span class="separator">/</span><span class="js-path-segment d-inline-block wb-break-all"><a data-pjax="true" rel="nofollow" href="/mebjas/mebjas.github.io/tree/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets"><span>assets</span></a></span><span class="separator">/</span><span class="js-path-segment d-inline-block wb-break-all"><a data-pjax="true" rel="nofollow" href="/mebjas/mebjas.github.io/tree/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research"><span>research</span></a></span><span class="separator">/</span><span class="js-path-segment d-inline-block wb-break-all"><a data-pjax="true" rel="nofollow" href="/mebjas/mebjas.github.io/tree/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion"><span>exposure_fusion</span></a></span><span class="separator">/</span><strong class="final-path">ef.js</strong></span>
  <clipboard-copy aria-label="Copy file path to clipboard" value="assets/research/exposure_fusion/ef.js" data-view-component="true" class="btn btn-sm">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copy">
    <path fill-rule="evenodd" d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 010 1.5h-1.5a.25.25 0 00-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 00.25-.25v-1.5a.75.75 0 011.5 0v1.5A1.75 1.75 0 019.25 16h-7.5A1.75 1.75 0 010 14.25v-7.5z"></path><path fill-rule="evenodd" d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0114.25 11h-7.5A1.75 1.75 0 015 9.25v-7.5zm1.75-.25a.25.25 0 00-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 00.25-.25v-7.5a.25.25 0 00-.25-.25h-7.5z"></path>
</svg>
    <svg style="display: none;" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check color-fg-success">
    <path fill-rule="evenodd" d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"></path>
</svg>
</clipboard-copy>
</div>

<div class="line-age-legend float-right mt-n4 f6">
  <span>Newer</span>
  <ol class="d-inline-block mx-1 list-style-none">
      <li class="heat d-inline-block" data-heat="1"></li>
      <li class="heat d-inline-block" data-heat="2"></li>
      <li class="heat d-inline-block" data-heat="3"></li>
      <li class="heat d-inline-block" data-heat="4"></li>
      <li class="heat d-inline-block" data-heat="5"></li>
      <li class="heat d-inline-block" data-heat="6"></li>
      <li class="heat d-inline-block" data-heat="7"></li>
      <li class="heat d-inline-block" data-heat="8"></li>
      <li class="heat d-inline-block" data-heat="9"></li>
      <li class="heat d-inline-block" data-heat="10"></li>
  </ol>
  <span>Older</span>
</div>


  <div class="file">
    <div class="file-header py-2 pl-3 pr-2">

      <div class="file-actions pt-0">
        <div data-view-component="true" class="BtnGroup">
    <a href="/mebjas/mebjas.github.io/raw/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js" id="raw-url" data-view-component="true" class="btn-sm btn BtnGroup-item">  Raw
</a>
    <a href="/mebjas/mebjas.github.io/blob/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js" data-view-component="true" class="js-update-url-with-hash btn-sm btn BtnGroup-item">  Normal view
</a>
    <a href="/mebjas/mebjas.github.io/commits/37b6ef86ed96cb42f3f4a2350abcdd8f658a79f2/assets/research/exposure_fusion/ef.js" rel="nofollow" data-view-component="true" class="btn-sm btn BtnGroup-item">  History
</a>
</div>      </div>


  

      <div class="file-info" style="line-height: 28px">
        <span style="margin-left: 2px">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v11.5c0 .138.112.25.25.25h8.5a.25.25 0 00.25-.25V6H9.75A1.75 1.75 0 018 4.25V1.5H3.75zm5.75.56v2.19c0 .138.112.25.25.25h2.19L9.5 2.06zM2 1.75C2 .784 2.784 0 3.75 0h5.086c.464 0 .909.184 1.237.513l3.414 3.414c.329.328.513.773.513 1.237v8.086A1.75 1.75 0 0112.25 15h-8.5A1.75 1.75 0 012 13.25V1.75z"></path>
</svg>
        </span>
        <span class="file-mode" title="File Mode">100644</span>
        <span class="file-info-divider"></span>
          563 lines (494 sloc)
          <span class="file-info-divider"></span>
        18.5 KB
      </div>
    </div>

    <div class="blob-wrapper">
      <div class="blame-container  highlight data js-file-line-container tab-size" data-tab-size="8" data-paste-markdown-skip>

          <div class="blame-hunk d-flex color-border-muted border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-3 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start  " >
  <div class="AvatarStack-body" aria-label="mebjas" >
      <a class="avatar avatar-user" style="width:20px;height:20px;" data-skip-pjax="true" data-test-selector="commits-avatar-stack-avatar-link" data-hovercard-type="user" data-hovercard-url="/users/mebjas/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mebjas">
        <img data-test-selector="commits-avatar-stack-avatar-image" src="https://avatars.githubusercontent.com/u/3007365?s=40&amp;v=4" width="20" height="20" alt="@mebjas" class=" avatar-user" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                      <a class="message f6 color-fg-default markdown-title" data-hovercard-type="commit" data-hovercard-url="/mebjas/mebjas.github.io/commit/84e905b6a914c3807904134619737d39fa52451d/hovercard" data-pjax="true" href="/mebjas/mebjas.github.io/commit/84e905b6a914c3807904134619737d39fa52451d">Update code references</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2021-02-14T09:56:28Z" data-view-component="true" class="no-wrap">Feb 14, 2021</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
              <a class="reblame-link Link--onHover no-underline tooltipped tooltipped-e d-inline-block pr-1" aria-label="View blame prior to this change" href="/mebjas/mebjas.github.io/blame/dacdca711f55b226e06342a90634f025373fbc71/assets/research/exposure_fusion/ef.js"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-versions">
    <path fill-rule="evenodd" d="M7.75 14A1.75 1.75 0 016 12.25v-8.5C6 2.784 6.784 2 7.75 2h6.5c.966 0 1.75.784 1.75 1.75v8.5A1.75 1.75 0 0114.25 14h-6.5zm-.25-1.75c0 .138.112.25.25.25h6.5a.25.25 0 00.25-.25v-8.5a.25.25 0 00-.25-.25h-6.5a.25.25 0 00-.25.25v8.5zM4.9 3.508a.75.75 0 01-.274 1.025.25.25 0 00-.126.217v6.5a.25.25 0 00.126.217.75.75 0 01-.752 1.298A1.75 1.75 0 013 11.25v-6.5c0-.649.353-1.214.874-1.516a.75.75 0 011.025.274zM1.625 5.533a.75.75 0 10-.752-1.299A1.75 1.75 0 000 5.75v4.5c0 .649.353 1.214.874 1.515a.75.75 0 10.752-1.298.25.25 0 01-.126-.217v-4.5a.25.25 0 01.126-.217z"></path>
</svg></a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L1">1</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC1"><span class=pl-c>/**</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L2">2</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC2"><span class=pl-c> * Do not look at this code and use it to judge me. The intent of writing this peice of code was</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L3">3</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC3"><span class=pl-c> * to understand how exposure fusion works (i.e. with visualization of each steps) and not</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L4">4</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC4"><span class=pl-c> * writing a library or any reusable component.</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L5">5</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC5"><span class=pl-c> */</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L6">6</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC6">
</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex color-border-muted border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-3 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start  " >
  <div class="AvatarStack-body" aria-label="mebjas" >
      <a class="avatar avatar-user" style="width:20px;height:20px;" data-skip-pjax="true" data-test-selector="commits-avatar-stack-avatar-link" data-hovercard-type="user" data-hovercard-url="/users/mebjas/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mebjas">
        <img data-test-selector="commits-avatar-stack-avatar-image" src="https://avatars.githubusercontent.com/u/3007365?s=40&amp;v=4" width="20" height="20" alt="@mebjas" class=" avatar-user" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                      <a class="message f6 color-fg-default markdown-title" data-hovercard-type="commit" data-hovercard-url="/mebjas/mebjas.github.io/commit/05355ef7f2e7d001305788b75446eeded3a5210d/hovercard" data-pjax="true" href="/mebjas/mebjas.github.io/commit/05355ef7f2e7d001305788b75446eeded3a5210d">Add exposure fusion visualizer and modify research layout</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2021-02-14T09:48:42Z" data-view-component="true" class="no-wrap">Feb 14, 2021</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
              
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L7">7</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC7"><span class=pl-k>let</span> <span class=pl-s1>input1</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>getElementById</span><span class=pl-kos>(</span><span class=pl-s>&#39;input_1&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L8">8</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC8"><span class=pl-k>let</span> <span class=pl-s1>input2</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>getElementById</span><span class=pl-kos>(</span><span class=pl-s>&#39;input_2&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L9">9</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC9"><span class=pl-k>let</span> <span class=pl-s1>input3</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>getElementById</span><span class=pl-kos>(</span><span class=pl-s>&#39;input_3&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L10">10</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC10"><span class=pl-k>let</span> <span class=pl-s1>images</span> <span class=pl-c1>=</span> <span class=pl-kos>[</span><span class=pl-s1>input1</span><span class=pl-kos>,</span> <span class=pl-s1>input2</span><span class=pl-kos>,</span> <span class=pl-s1>input3</span><span class=pl-kos>]</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L11">11</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC11"><span class=pl-k>let</span> <span class=pl-s1>weightsCanvas</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>getElementById</span><span class=pl-kos>(</span><span class=pl-s>&#39;weights_canvas&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L12">12</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC12"><span class=pl-k>let</span> <span class=pl-s1>mnWeightsCanvas</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>getElementById</span><span class=pl-kos>(</span><span class=pl-s>&#39;merged_weights_canvas&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L13">13</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC13"><span class=pl-k>let</span> <span class=pl-s1>pyrMmergeCanvas</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>getElementById</span><span class=pl-kos>(</span><span class=pl-s>&#39;pyr_merge_canvas&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L14">14</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC14"><span class=pl-k>let</span> <span class=pl-s1>datasetSelector</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>getElementById</span><span class=pl-kos>(</span><span class=pl-s>&#39;dataset_selector&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L15">15</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC15"><span class=pl-k>let</span> <span class=pl-s1>maps</span> <span class=pl-c1>=</span> <span class=pl-kos>[</span><span class=pl-s>&quot;Contrast&quot;</span><span class=pl-kos>,</span> <span class=pl-s>&quot;Saturation&quot;</span><span class=pl-kos>,</span> <span class=pl-s>&quot;Exposure (scaled up)&quot;</span><span class=pl-kos>]</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L16">16</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC16"><span class=pl-k>let</span> <span class=pl-s1>maxPyrLevel</span> <span class=pl-c1>=</span> <span class=pl-c1>4</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L17">17</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC17">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L18">18</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC18"><span class=pl-k>function</span> <span class=pl-en>exponentialCalculation</span><span class=pl-kos>(</span><span class=pl-s1>val</span><span class=pl-kos>,</span> <span class=pl-s1>sigma</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L19">19</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC19">    <span class=pl-k>let</span> <span class=pl-s1>delta</span> <span class=pl-c1>=</span> <span class=pl-kos>(</span><span class=pl-kos>(</span><span class=pl-s1>val</span> <span class=pl-c1>/</span> <span class=pl-c1>255.0</span><span class=pl-kos>)</span> <span class=pl-c1>-</span> <span class=pl-c1>0.5</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L20">20</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC20">    <span class=pl-k>let</span> <span class=pl-s1>twoSigmaSq</span> <span class=pl-c1>=</span> <span class=pl-kos>(</span><span class=pl-c1>2</span> <span class=pl-c1>*</span> <span class=pl-s1>sigma</span> <span class=pl-c1>*</span> <span class=pl-s1>sigma</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L21">21</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC21">    <span class=pl-k>return</span> <span class=pl-v>Math</span><span class=pl-kos>.</span><span class=pl-en>exp</span><span class=pl-kos>(</span> <span class=pl-c1>-</span> <span class=pl-s1>delta</span> <span class=pl-c1>*</span> <span class=pl-s1>delta</span> <span class=pl-c1>/</span> <span class=pl-s1>twoSigmaSq</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L22">22</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC22"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L23">23</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC23">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L24">24</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC24"><span class=pl-c>// fix this function</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L25">25</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC25"><span class=pl-k>function</span> <span class=pl-en>normalizeAndScaleCV8U</span><span class=pl-kos>(</span><span class=pl-s1>src</span><span class=pl-kos>,</span> <span class=pl-s1>min</span><span class=pl-kos>,</span> <span class=pl-s1>max</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L26">26</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC26">    <span class=pl-k>let</span> <span class=pl-s1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-c1>cols</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L27">27</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC27">    <span class=pl-k>let</span> <span class=pl-s1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-c1>rows</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L28">28</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC28">    <span class=pl-k>let</span> <span class=pl-s1>channels</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>channels</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L29">29</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC29">    <span class=pl-smi>console</span><span class=pl-kos>.</span><span class=pl-en>assert</span><span class=pl-kos>(</span><span class=pl-s1>channels</span> <span class=pl-c1>==</span> <span class=pl-c1>1</span><span class=pl-kos>,</span> <span class=pl-s>&quot;Channels expected to be 1&quot;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L30">30</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC30">    <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-c1>!</span><span class=pl-s1>min</span> <span class=pl-c1>||</span> <span class=pl-c1>!</span><span class=pl-s1>max</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L31">31</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC31">        <span class=pl-s1>min</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>ucharAt</span><span class=pl-kos>(</span><span class=pl-c1>0</span><span class=pl-kos>,</span> <span class=pl-c1>0</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L32">32</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC32">        <span class=pl-s1>max</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>ucharAt</span><span class=pl-kos>(</span><span class=pl-c1>0</span><span class=pl-kos>,</span> <span class=pl-c1>0</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L33">33</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC33">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>y</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>y</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>height</span><span class=pl-kos>;</span> <span class=pl-c1>++</span><span class=pl-s1>y</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L34">34</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC34">            <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>x</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>x</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>width</span><span class=pl-kos>;</span> <span class=pl-c1>++</span><span class=pl-s1>x</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L35">35</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC35">                <span class=pl-k>let</span> <span class=pl-s1>val</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>ucharAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L36">36</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC36">                <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-s1>val</span> <span class=pl-c1>&gt;</span> <span class=pl-s1>max</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L37">37</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC37">                    <span class=pl-s1>max</span> <span class=pl-c1>=</span> <span class=pl-s1>val</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L38">38</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC38">                <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L39">39</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC39">                <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-s1>val</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>min</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L40">40</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC40">                    <span class=pl-s1>min</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>val</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L41">41</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC41">                <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L42">42</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC42">            <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L43">43</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC43">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L44">44</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC44">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L45">45</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC45">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L46">46</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC46">    <span class=pl-k>let</span> <span class=pl-s1>result</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-s1>height</span><span class=pl-kos>,</span> <span class=pl-s1>width</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_8U</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L47">47</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC47">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>y</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>y</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>height</span><span class=pl-kos>;</span> <span class=pl-c1>++</span><span class=pl-s1>y</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L48">48</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC48">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>x</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>x</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>width</span><span class=pl-kos>;</span> <span class=pl-c1>++</span><span class=pl-s1>x</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L49">49</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC49">            <span class=pl-k>let</span> <span class=pl-s1>val</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>ucharAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L50">50</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC50">            <span class=pl-k>let</span> <span class=pl-s1>normalizedValue</span> <span class=pl-c1>=</span> <span class=pl-kos>(</span><span class=pl-s1>val</span> <span class=pl-c1>-</span> <span class=pl-s1>min</span><span class=pl-kos>)</span> <span class=pl-c1>/</span> <span class=pl-kos>(</span><span class=pl-s1>max</span> <span class=pl-c1>-</span> <span class=pl-s1>min</span><span class=pl-kos>)</span> <span class=pl-c1>*</span> <span class=pl-c1>255</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L51">51</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC51">            <span class=pl-s1>result</span><span class=pl-kos>.</span><span class=pl-en>ucharPtr</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>[</span><span class=pl-c1>0</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-s1>normalizedValue</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L52">52</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC52">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L53">53</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC53">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L54">54</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC54">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L55">55</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC55">    <span class=pl-k>return</span> <span class=pl-s1>result</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L56">56</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC56"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L57">57</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC57">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L58">58</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC58"><span class=pl-k>function</span> <span class=pl-en>loadAllImages</span><span class=pl-kos>(</span><span class=pl-s1>allImagesLoadedCallback</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L59">59</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC59">    <span class=pl-k>let</span> <span class=pl-s1>cvImages</span> <span class=pl-c1>=</span> <span class=pl-kos>[</span><span class=pl-c1>undefined</span><span class=pl-kos>,</span> <span class=pl-c1>undefined</span><span class=pl-kos>,</span> <span class=pl-c1>undefined</span><span class=pl-kos>]</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L60">60</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC60">    <span class=pl-k>let</span> <span class=pl-s1>countImageLoaded</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L61">61</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC61">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L62">62</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC62">    <span class=pl-k>function</span> <span class=pl-en>onLoad</span><span class=pl-kos>(</span><span class=pl-s1>index</span><span class=pl-kos>,</span> <span class=pl-s1>image</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L63">63</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC63">        <span class=pl-s1>countImageLoaded</span><span class=pl-c1>++</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L64">64</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC64">        <span class=pl-s1>cvImages</span><span class=pl-kos>[</span><span class=pl-s1>index</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>imread</span><span class=pl-kos>(</span><span class=pl-s1>image</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L65">65</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC65">        <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-s1>countImageLoaded</span> <span class=pl-c1>==</span> <span class=pl-s1>images</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L66">66</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC66">            <span class=pl-s1>allImagesLoadedCallback</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L67">67</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC67">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L68">68</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC68">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L69">69</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC69">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L70">70</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC70">    <span class=pl-s1>images</span><span class=pl-kos>.</span><span class=pl-en>forEach</span><span class=pl-kos>(</span><span class=pl-k>function</span><span class=pl-kos>(</span><span class=pl-s1>ignore</span><span class=pl-kos>,</span> <span class=pl-s1>index</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L71">71</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC71">        <span class=pl-k>let</span> <span class=pl-s1>image</span> <span class=pl-c1>=</span> <span class=pl-s1>images</span><span class=pl-kos>[</span><span class=pl-s1>index</span><span class=pl-kos>]</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L72">72</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC72">        <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-s1>image</span><span class=pl-kos>.</span><span class=pl-c1>complete</span> <span class=pl-c1>&amp;&amp;</span> <span class=pl-s1>image</span><span class=pl-kos>.</span><span class=pl-c1>naturalHeight</span> <span class=pl-c1>!==</span> <span class=pl-c1>0</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L73">73</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC73">            <span class=pl-en>onLoad</span><span class=pl-kos>(</span><span class=pl-s1>index</span><span class=pl-kos>,</span> <span class=pl-s1>image</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L74">74</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC74">        <span class=pl-kos>}</span> <span class=pl-k>else</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L75">75</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC75">            <span class=pl-s1>image</span><span class=pl-kos>.</span><span class=pl-en>onload</span> <span class=pl-c1>=</span> <span class=pl-k>function</span><span class=pl-kos>(</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L76">76</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC76">                <span class=pl-en>onLoad</span><span class=pl-kos>(</span><span class=pl-s1>index</span><span class=pl-kos>,</span> <span class=pl-s1>image</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L77">77</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC77">            <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L78">78</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC78">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L79">79</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC79">    <span class=pl-kos>}</span><span class=pl-kos>)</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L80">80</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC80"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L81">81</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC81">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L82">82</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC82"><span class=pl-k>function</span> <span class=pl-en>getContrastMap</span><span class=pl-kos>(</span><span class=pl-s1>src</span><span class=pl-kos>,</span> <span class=pl-s1>normalize</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L83">83</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC83">    <span class=pl-c>// Contrast</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L84">84</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC84">    <span class=pl-k>let</span> <span class=pl-s1>tmp</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L85">85</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC85">    <span class=pl-k>let</span> <span class=pl-s1>dst</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L86">86</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC86">    <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>cvtColor</span><span class=pl-kos>(</span><span class=pl-s1>src</span><span class=pl-kos>,</span> <span class=pl-s1>tmp</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>COLOR_RGB2GRAY</span><span class=pl-kos>,</span> <span class=pl-c1>0</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L87">87</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC87">    <span class=pl-s1>tmp</span><span class=pl-kos>.</span><span class=pl-en>convertTo</span><span class=pl-kos>(</span><span class=pl-s1>tmp</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_32F</span><span class=pl-kos>,</span> <span class=pl-c1>1</span> <span class=pl-c1>/</span> <span class=pl-c1>255</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L88">88</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC88">    <span class=pl-c>// You can try more different parameters</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L89">89</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC89">    <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>Laplacian</span><span class=pl-kos>(</span><span class=pl-s1>tmp</span><span class=pl-kos>,</span> <span class=pl-s1>dst</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_32F</span><span class=pl-kos>,</span> <span class=pl-c1>3</span><span class=pl-kos>,</span> <span class=pl-c1>10</span><span class=pl-kos>,</span> <span class=pl-c1>0</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>BORDER_DEFAULT</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L90">90</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC90">    <span class=pl-s1>tmp</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L91">91</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC91">    <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-s1>normalize</span> <span class=pl-c1>!==</span> <span class=pl-c1>true</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L92">92</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC92">        <span class=pl-k>return</span> <span class=pl-s1>dst</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L93">93</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC93">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L94">94</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC94">    <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>normalize</span><span class=pl-kos>(</span><span class=pl-s1>dst</span><span class=pl-kos>,</span> <span class=pl-s1>dst</span><span class=pl-kos>,</span> <span class=pl-c1>0</span><span class=pl-kos>,</span> <span class=pl-c1>1</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>NORM_MINMAX</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L95">95</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC95">    <span class=pl-s1>dst</span><span class=pl-kos>.</span><span class=pl-en>convertTo</span><span class=pl-kos>(</span><span class=pl-s1>dst</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_8U</span><span class=pl-kos>,</span> <span class=pl-c1>255</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L96">96</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC96">    <span class=pl-k>return</span> <span class=pl-s1>dst</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L97">97</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC97"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L98">98</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC98">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L99">99</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC99"><span class=pl-k>function</span> <span class=pl-en>getSaturationMap</span><span class=pl-kos>(</span><span class=pl-s1>src</span><span class=pl-kos>,</span> <span class=pl-s1>normalize</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L100">100</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC100">    <span class=pl-k>let</span> <span class=pl-s1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-c1>cols</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L101">101</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC101">    <span class=pl-k>let</span> <span class=pl-s1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-c1>rows</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L102">102</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC102">    <span class=pl-k>let</span> <span class=pl-s1>channels</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>channels</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L103">103</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC103">    <span class=pl-k>let</span> <span class=pl-s1>dst</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-s1>height</span><span class=pl-kos>,</span> <span class=pl-s1>width</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_32F</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L104">104</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC104">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>y</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>y</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>height</span><span class=pl-kos>;</span> <span class=pl-c1>++</span><span class=pl-s1>y</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L105">105</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC105">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>x</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>x</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>width</span><span class=pl-kos>;</span> <span class=pl-c1>++</span><span class=pl-s1>x</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L106">106</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC106">            <span class=pl-k>let</span> <span class=pl-s1>r</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>ucharAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span> <span class=pl-c1>*</span> <span class=pl-s1>channels</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L107">107</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC107">            <span class=pl-k>let</span> <span class=pl-s1>g</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>ucharAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span> <span class=pl-c1>*</span> <span class=pl-s1>channels</span> <span class=pl-c1>+</span> <span class=pl-c1>1</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L108">108</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC108">            <span class=pl-k>let</span> <span class=pl-s1>b</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>ucharAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span> <span class=pl-c1>*</span> <span class=pl-s1>channels</span> <span class=pl-c1>+</span> <span class=pl-c1>2</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L109">109</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC109">            <span class=pl-k>let</span> <span class=pl-s1>mean</span> <span class=pl-c1>=</span> <span class=pl-kos>(</span><span class=pl-s1>r</span> <span class=pl-c1>+</span> <span class=pl-s1>g</span> <span class=pl-c1>+</span> <span class=pl-s1>b</span><span class=pl-kos>)</span> <span class=pl-c1>/</span> <span class=pl-c1>3</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L110">110</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC110">            <span class=pl-k>let</span> <span class=pl-s1>saturation</span> <span class=pl-c1>=</span> <span class=pl-v>Math</span><span class=pl-kos>.</span><span class=pl-en>sqrt</span><span class=pl-kos>(</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L111">111</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC111">                <span class=pl-kos>(</span><span class=pl-kos>(</span><span class=pl-s1>r</span> <span class=pl-c1>-</span> <span class=pl-s1>mean</span><span class=pl-kos>)</span> <span class=pl-c1>*</span> <span class=pl-kos>(</span><span class=pl-s1>r</span> <span class=pl-c1>-</span> <span class=pl-s1>mean</span><span class=pl-kos>)</span> <span class=pl-c1>+</span> <span class=pl-kos>(</span><span class=pl-s1>g</span> <span class=pl-c1>-</span> <span class=pl-s1>mean</span><span class=pl-kos>)</span> <span class=pl-c1>*</span> <span class=pl-kos>(</span><span class=pl-s1>g</span> <span class=pl-c1>-</span> <span class=pl-s1>mean</span><span class=pl-kos>)</span> <span class=pl-c1>+</span> <span class=pl-kos>(</span><span class=pl-s1>b</span> <span class=pl-c1>-</span> <span class=pl-s1>mean</span><span class=pl-kos>)</span> <span class=pl-c1>*</span> <span class=pl-kos>(</span><span class=pl-s1>b</span> <span class=pl-c1>-</span> <span class=pl-s1>mean</span><span class=pl-kos>)</span><span class=pl-kos>)</span> <span class=pl-c1>/</span> <span class=pl-c1>3</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L112">112</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC112">            <span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L113">113</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC113">            <span class=pl-s1>dst</span><span class=pl-kos>.</span><span class=pl-en>floatPtr</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>[</span><span class=pl-c1>0</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-s1>saturation</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L114">114</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC114">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L115">115</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC115">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L116">116</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC116">    <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-s1>normalize</span> <span class=pl-c1>!==</span> <span class=pl-c1>true</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L117">117</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC117">        <span class=pl-k>return</span> <span class=pl-s1>dst</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L118">118</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC118">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L119">119</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC119">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L120">120</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC120">    <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>normalize</span><span class=pl-kos>(</span><span class=pl-s1>dst</span><span class=pl-kos>,</span> <span class=pl-s1>dst</span><span class=pl-kos>,</span> <span class=pl-c1>0</span><span class=pl-kos>,</span> <span class=pl-c1>1</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>NORM_MINMAX</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L121">121</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC121">    <span class=pl-s1>dst</span><span class=pl-kos>.</span><span class=pl-en>convertTo</span><span class=pl-kos>(</span><span class=pl-s1>dst</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_8U</span><span class=pl-kos>,</span> <span class=pl-c1>255</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L122">122</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC122">    <span class=pl-k>return</span> <span class=pl-s1>dst</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L123">123</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC123"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L124">124</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC124">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L125">125</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC125"><span class=pl-k>function</span> <span class=pl-en>getExposureMap</span><span class=pl-kos>(</span><span class=pl-s1>src</span><span class=pl-kos>,</span> <span class=pl-s1>normalize</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L126">126</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC126">    <span class=pl-k>let</span> <span class=pl-s1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-c1>cols</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L127">127</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC127">    <span class=pl-k>let</span> <span class=pl-s1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-c1>rows</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L128">128</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC128">    <span class=pl-k>let</span> <span class=pl-s1>channels</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>channels</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L129">129</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC129">    <span class=pl-k>let</span> <span class=pl-s1>dst</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-s1>height</span><span class=pl-kos>,</span> <span class=pl-s1>width</span><span class=pl-kos>,</span> <span class=pl-kos>(</span><span class=pl-s1>normalize</span><span class=pl-kos>)</span> ? <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_8U</span> : <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_32F</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L130">130</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC130">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L131">131</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC131">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>y</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>y</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>height</span><span class=pl-kos>;</span> <span class=pl-c1>++</span><span class=pl-s1>y</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L132">132</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC132">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>x</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>x</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>width</span><span class=pl-kos>;</span> <span class=pl-c1>++</span><span class=pl-s1>x</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L133">133</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC133">            <span class=pl-k>let</span> <span class=pl-s1>r</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>ucharAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span> <span class=pl-c1>*</span> <span class=pl-s1>channels</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L134">134</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC134">            <span class=pl-k>let</span> <span class=pl-s1>g</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>ucharAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span> <span class=pl-c1>*</span> <span class=pl-s1>channels</span> <span class=pl-c1>+</span> <span class=pl-c1>1</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L135">135</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC135">            <span class=pl-k>let</span> <span class=pl-s1>b</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-en>ucharAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span> <span class=pl-c1>*</span> <span class=pl-s1>channels</span> <span class=pl-c1>+</span> <span class=pl-c1>2</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L136">136</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC136">            <span class=pl-k>let</span> <span class=pl-s1>e</span> <span class=pl-c1>=</span> <span class=pl-en>exponentialCalculation</span><span class=pl-kos>(</span><span class=pl-s1>r</span><span class=pl-kos>,</span> <span class=pl-c1>0.2</span><span class=pl-kos>)</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L137">137</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC137">                <span class=pl-c1>*</span> <span class=pl-en>exponentialCalculation</span><span class=pl-kos>(</span><span class=pl-s1>g</span><span class=pl-kos>,</span> <span class=pl-c1>0.2</span><span class=pl-kos>)</span> <span class=pl-c1>*</span> <span class=pl-en>exponentialCalculation</span><span class=pl-kos>(</span><span class=pl-s1>b</span><span class=pl-kos>,</span> <span class=pl-c1>0.2</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L138">138</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC138">            <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-s1>normalize</span> <span class=pl-c1>==</span> <span class=pl-c1>true</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L139">139</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC139">                <span class=pl-s1>e</span> <span class=pl-c1>*=</span> <span class=pl-c1>255</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L140">140</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC140">                <span class=pl-s1>dst</span><span class=pl-kos>.</span><span class=pl-en>ucharPtr</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>[</span><span class=pl-c1>0</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-s1>e</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L141">141</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC141">            <span class=pl-kos>}</span> <span class=pl-k>else</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L142">142</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC142">                <span class=pl-s1>dst</span><span class=pl-kos>.</span><span class=pl-en>floatPtr</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>[</span><span class=pl-c1>0</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-s1>e</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L143">143</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC143">            <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L144">144</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC144">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L145">145</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC145">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L146">146</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC146">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L147">147</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC147">    <span class=pl-k>return</span> <span class=pl-s1>dst</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L148">148</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC148"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L149">149</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC149">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L150">150</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC150"><span class=pl-k>function</span> <span class=pl-en>renderWeight</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>,</span> <span class=pl-s1>mapType</span><span class=pl-kos>,</span> <span class=pl-s1>imageIndex</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L151">151</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC151">    <span class=pl-k>let</span> <span class=pl-s1>src</span> <span class=pl-c1>=</span> <span class=pl-s1>cvImages</span><span class=pl-kos>[</span><span class=pl-s1>imageIndex</span><span class=pl-kos>]</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L152">152</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC152">    <span class=pl-k>let</span> <span class=pl-s1>canvasId</span> <span class=pl-c1>=</span> <span class=pl-s>`__weight_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>mapType</span><span class=pl-kos>}</span></span>_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>imageIndex</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L153">153</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC153">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L154">154</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC154">    <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-s1>mapType</span> <span class=pl-c1>==</span> <span class=pl-s1>maps</span><span class=pl-kos>[</span><span class=pl-c1>0</span><span class=pl-kos>]</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L155">155</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC155">        <span class=pl-c>// Contrast</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L156">156</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC156">        <span class=pl-k>let</span> <span class=pl-s1>dst</span> <span class=pl-c1>=</span> <span class=pl-en>getContrastMap</span><span class=pl-kos>(</span><span class=pl-s1>src</span><span class=pl-kos>,</span> <span class=pl-c>/* normalize= */</span> <span class=pl-c1>true</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L157">157</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC157">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>imshow</span><span class=pl-kos>(</span><span class=pl-s1>canvasId</span><span class=pl-kos>,</span> <span class=pl-s1>dst</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L158">158</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC158">        <span class=pl-s1>dst</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L159">159</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC159">    <span class=pl-kos>}</span> <span class=pl-k>else</span> <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-s1>mapType</span> <span class=pl-c1>==</span> <span class=pl-s1>maps</span><span class=pl-kos>[</span><span class=pl-c1>1</span><span class=pl-kos>]</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L160">160</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC160">        <span class=pl-k>let</span> <span class=pl-s1>dst</span> <span class=pl-c1>=</span> <span class=pl-en>getSaturationMap</span><span class=pl-kos>(</span><span class=pl-s1>src</span><span class=pl-kos>,</span> <span class=pl-c>/* normalize= */</span> <span class=pl-c1>true</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L161">161</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC161">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>imshow</span><span class=pl-kos>(</span><span class=pl-s1>canvasId</span><span class=pl-kos>,</span> <span class=pl-s1>dst</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L162">162</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC162">        <span class=pl-s1>dst</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L163">163</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC163">    <span class=pl-kos>}</span> <span class=pl-k>else</span> <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-s1>mapType</span> <span class=pl-c1>==</span> <span class=pl-s1>maps</span><span class=pl-kos>[</span><span class=pl-c1>2</span><span class=pl-kos>]</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L164">164</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC164">        <span class=pl-k>let</span> <span class=pl-s1>dst</span> <span class=pl-c1>=</span> <span class=pl-en>getExposureMap</span><span class=pl-kos>(</span><span class=pl-s1>src</span><span class=pl-kos>,</span> <span class=pl-c>/* normalize= */</span> <span class=pl-c1>true</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L165">165</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC165">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>imshow</span><span class=pl-kos>(</span><span class=pl-s1>canvasId</span><span class=pl-kos>,</span> <span class=pl-s1>dst</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L166">166</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC166">        <span class=pl-s1>dst</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L167">167</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC167">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L168">168</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC168"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L169">169</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC169">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L170">170</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC170"><span class=pl-k>function</span> <span class=pl-en>computeWeights</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L171">171</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC171">    <span class=pl-k>let</span> <span class=pl-s1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>input1</span><span class=pl-kos>.</span><span class=pl-c1>width</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L172">172</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC172">    <span class=pl-k>let</span> <span class=pl-s1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>input1</span><span class=pl-kos>.</span><span class=pl-c1>height</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L173">173</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC173">    <span class=pl-k>let</span> <span class=pl-s1>loggingElement</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L174">174</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC174">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L175">175</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC175">    <span class=pl-k>function</span> <span class=pl-en>renderUi</span><span class=pl-kos>(</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L176">176</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC176">        <span class=pl-s1>loggingElement</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L177">177</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC177">        <span class=pl-s1>weightsCanvas</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L178">178</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC178">        <span class=pl-s1>weightsCanvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>loggingElement</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L179">179</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC179">        <span class=pl-s1>loggingElement</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;Computing weights...&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L180">180</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC180">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L181">181</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC181">        <span class=pl-k>let</span> <span class=pl-s1>canvas</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L182">182</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC182">        <span class=pl-s1>weightsCanvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>canvas</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L183">183</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC183">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L184">184</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC184">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>m</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>m</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>maps</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span> <span class=pl-s1>m</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L185">185</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC185">            <span class=pl-k>let</span> <span class=pl-s1>rowHeader</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L186">186</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC186">            <span class=pl-s1>rowHeader</span><span class=pl-kos>.</span><span class=pl-c1>className</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;weight_header&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L187">187</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC187">            <span class=pl-s1>rowHeader</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s1>maps</span><span class=pl-kos>[</span><span class=pl-s1>m</span><span class=pl-kos>]</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L188">188</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC188">            <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>rowHeader</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L189">189</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC189">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L190">190</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC190">            <span class=pl-k>let</span> <span class=pl-s1>rowDiv</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L191">191</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC191">            <span class=pl-s1>rowDiv</span><span class=pl-kos>.</span><span class=pl-c1>id</span> <span class=pl-c1>=</span> <span class=pl-s>`__weight_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>maps</span><span class=pl-kos>[</span><span class=pl-s1>m</span><span class=pl-kos>]</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L192">192</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC192">            <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>cvImages</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L193">193</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC193">                <span class=pl-k>let</span> <span class=pl-s1>canvas</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;canvas&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L194">194</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC194">                <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>id</span> <span class=pl-c1>=</span> <span class=pl-s>`__weight_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>maps</span><span class=pl-kos>[</span><span class=pl-s1>m</span><span class=pl-kos>]</span><span class=pl-kos>}</span></span>_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>i</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L195">195</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC195">                <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>className</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;weight_canvas&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L196">196</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC196">                <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>width</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L197">197</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC197">                <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>height</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L198">198</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC198">                <span class=pl-s1>rowDiv</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>canvas</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L199">199</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC199">            <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L200">200</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC200">            <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>rowDiv</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L201">201</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC201">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L202">202</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC202">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L203">203</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC203">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L204">204</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC204">    <span class=pl-en>renderUi</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L205">205</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC205">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>m</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>m</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>maps</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span> <span class=pl-s1>m</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L206">206</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC206">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>cvImages</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L207">207</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC207">            <span class=pl-en>renderWeight</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>,</span> <span class=pl-s1>maps</span><span class=pl-kos>[</span><span class=pl-s1>m</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-s1>i</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L208">208</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC208">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L209">209</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC209">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L210">210</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC210">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L211">211</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC211">    <span class=pl-s1>loggingElement</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L212">212</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC212"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L213">213</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC213">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L214">214</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC214"><span class=pl-k>function</span> <span class=pl-en>computeMergedMap</span><span class=pl-kos>(</span><span class=pl-s1>src</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L215">215</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC215">    <span class=pl-k>let</span> <span class=pl-s1>contrastMap</span> <span class=pl-c1>=</span> <span class=pl-en>getContrastMap</span><span class=pl-kos>(</span><span class=pl-s1>src</span><span class=pl-kos>,</span> <span class=pl-c>/* normalize= */</span> <span class=pl-c1>false</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L216">216</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC216">    <span class=pl-k>let</span> <span class=pl-s1>saturationMap</span> <span class=pl-c1>=</span> <span class=pl-en>getSaturationMap</span><span class=pl-kos>(</span><span class=pl-s1>src</span><span class=pl-kos>,</span> <span class=pl-c>/* normalize= */</span> <span class=pl-c1>false</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L217">217</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC217">    <span class=pl-k>let</span> <span class=pl-s1>exposureMap</span> <span class=pl-c1>=</span> <span class=pl-en>getExposureMap</span><span class=pl-kos>(</span><span class=pl-s1>src</span><span class=pl-kos>,</span> <span class=pl-c>/* normalize= */</span> <span class=pl-c1>false</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L218">218</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC218">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L219">219</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC219">    <span class=pl-k>let</span> <span class=pl-s1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-c1>cols</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L220">220</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC220">    <span class=pl-k>let</span> <span class=pl-s1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>src</span><span class=pl-kos>.</span><span class=pl-c1>rows</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L221">221</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC221">    <span class=pl-k>let</span> <span class=pl-s1>mergedMap</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-s1>height</span><span class=pl-kos>,</span> <span class=pl-s1>width</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_32F</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L222">222</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC222">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>y</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>y</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>height</span><span class=pl-kos>;</span> <span class=pl-c1>++</span><span class=pl-s1>y</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L223">223</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC223">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>x</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>x</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>width</span><span class=pl-kos>;</span> <span class=pl-c1>++</span><span class=pl-s1>x</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L224">224</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC224">            <span class=pl-k>let</span> <span class=pl-s1>val</span> <span class=pl-c1>=</span> </div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L225">225</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC225">                <span class=pl-c>// contrastMap.floatAt(y, x) *</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L226">226</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC226">                <span class=pl-s1>saturationMap</span><span class=pl-kos>.</span><span class=pl-en>floatAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span> <span class=pl-c1>*</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L227">227</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC227">                <span class=pl-s1>exposureMap</span><span class=pl-kos>.</span><span class=pl-en>floatAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L228">228</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC228">            <span class=pl-s1>mergedMap</span><span class=pl-kos>.</span><span class=pl-en>floatPtr</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>[</span><span class=pl-c1>0</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-s1>val</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L229">229</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC229">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L230">230</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC230">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L231">231</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC231">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L232">232</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC232">    <span class=pl-s1>contrastMap</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L233">233</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC233">    <span class=pl-s1>saturationMap</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L234">234</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC234">    <span class=pl-s1>exposureMap</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L235">235</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC235">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L236">236</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC236">    <span class=pl-k>return</span> <span class=pl-s1>mergedMap</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L237">237</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC237"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L238">238</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC238">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L239">239</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC239"><span class=pl-k>function</span> <span class=pl-en>normalizeMergedMaps</span><span class=pl-kos>(</span><span class=pl-s1>mergedMaps</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L240">240</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC240">    <span class=pl-smi>console</span><span class=pl-kos>.</span><span class=pl-en>assert</span><span class=pl-kos>(</span><span class=pl-s1>mergedMaps</span><span class=pl-kos>.</span><span class=pl-c1>length</span> <span class=pl-c1>==</span> <span class=pl-c1>3</span><span class=pl-kos>,</span> <span class=pl-s>&quot;minimum three weights expected&quot;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L241">241</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC241">    <span class=pl-k>let</span> <span class=pl-s1>count</span> <span class=pl-c1>=</span> <span class=pl-s1>mergedMaps</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L242">242</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC242">    <span class=pl-k>let</span> <span class=pl-s1>normlaizedMergedMaps</span> <span class=pl-c1>=</span> <span class=pl-kos>[</span><span class=pl-c1>undefined</span><span class=pl-kos>,</span> <span class=pl-c1>undefined</span><span class=pl-kos>,</span> <span class=pl-c1>undefined</span><span class=pl-kos>]</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L243">243</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC243">    <span class=pl-k>let</span> <span class=pl-s1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>mergedMaps</span><span class=pl-kos>[</span><span class=pl-c1>0</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-c1>cols</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L244">244</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC244">    <span class=pl-k>let</span> <span class=pl-s1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>mergedMaps</span><span class=pl-kos>[</span><span class=pl-c1>0</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-c1>rows</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L245">245</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC245">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>count</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L246">246</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC246">        <span class=pl-s1>normlaizedMergedMaps</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-s1>height</span><span class=pl-kos>,</span> <span class=pl-s1>width</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_32F</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L247">247</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC247">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L248">248</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC248">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>y</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>y</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>height</span><span class=pl-kos>;</span> <span class=pl-c1>++</span><span class=pl-s1>y</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L249">249</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC249">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>x</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>x</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>width</span><span class=pl-kos>;</span> <span class=pl-c1>++</span><span class=pl-s1>x</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L250">250</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC250">            <span class=pl-k>let</span> <span class=pl-s1>sum</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L251">251</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC251">            <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>count</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L252">252</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC252">                <span class=pl-s1>sum</span> <span class=pl-c1>+=</span> <span class=pl-s1>mergedMaps</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>floatAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L253">253</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC253">            <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L254">254</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC254">            <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>count</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L255">255</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC255">                <span class=pl-k>let</span> <span class=pl-s1>val</span> <span class=pl-c1>=</span> <span class=pl-kos>(</span><span class=pl-s1>sum</span> <span class=pl-c1>==</span> <span class=pl-c1>0</span><span class=pl-kos>)</span> ? <span class=pl-c1>0.3333</span> : <span class=pl-kos>(</span><span class=pl-s1>mergedMaps</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>floatAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span> <span class=pl-c1>/</span> <span class=pl-s1>sum</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L256">256</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC256">                <span class=pl-s1>normlaizedMergedMaps</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>floatPtr</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>[</span><span class=pl-c1>0</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-s1>val</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L257">257</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC257">            <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L258">258</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC258">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L259">259</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC259">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L260">260</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC260">    <span class=pl-k>return</span> <span class=pl-s1>normlaizedMergedMaps</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L261">261</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC261"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L262">262</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC262">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L263">263</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC263"><span class=pl-k>function</span> <span class=pl-en>computeMergedWeights</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L264">264</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC264">    <span class=pl-k>let</span> <span class=pl-s1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>input1</span><span class=pl-kos>.</span><span class=pl-c1>width</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L265">265</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC265">    <span class=pl-k>let</span> <span class=pl-s1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>input1</span><span class=pl-kos>.</span><span class=pl-c1>height</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L266">266</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC266">    <span class=pl-k>let</span> <span class=pl-s1>loggingElement</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L267">267</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC267">    <span class=pl-k>function</span> <span class=pl-en>renderUi</span><span class=pl-kos>(</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L268">268</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC268">        <span class=pl-s1>loggingElement</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L269">269</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC269">        <span class=pl-s1>mnWeightsCanvas</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L270">270</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC270">        <span class=pl-s1>mnWeightsCanvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>loggingElement</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L271">271</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC271">        <span class=pl-s1>loggingElement</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;Computing merged weights...&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L272">272</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC272">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L273">273</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC273">        <span class=pl-k>let</span> <span class=pl-s1>canvas</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L274">274</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC274">        <span class=pl-s1>mnWeightsCanvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>canvas</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L275">275</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC275">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L276">276</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC276">        <span class=pl-k>let</span> <span class=pl-s1>rowHeader</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L277">277</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC277">        <span class=pl-s1>rowHeader</span><span class=pl-kos>.</span><span class=pl-c1>className</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;weight_header&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L278">278</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC278">        <span class=pl-s1>rowHeader</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;Merged &amp; Normalized weights&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L279">279</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC279">        <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>rowHeader</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L280">280</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC280">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L281">281</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC281">        <span class=pl-k>let</span> <span class=pl-s1>rowDiv</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L282">282</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC282">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>cvImages</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L283">283</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC283">            <span class=pl-k>let</span> <span class=pl-s1>canvas</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;canvas&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L284">284</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC284">            <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>id</span> <span class=pl-c1>=</span> <span class=pl-s>`__mnweight_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>i</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L285">285</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC285">            <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>className</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;weight_canvas&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L286">286</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC286">            <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>width</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L287">287</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC287">            <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>height</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L288">288</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC288">            <span class=pl-s1>rowDiv</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>canvas</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L289">289</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC289">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L290">290</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC290">        <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>rowDiv</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L291">291</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC291">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L292">292</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC292">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L293">293</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC293">    <span class=pl-en>renderUi</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L294">294</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC294">    <span class=pl-s1>mergedMaps</span> <span class=pl-c1>=</span> <span class=pl-kos>[</span><span class=pl-c1>undefined</span><span class=pl-kos>,</span> <span class=pl-c1>undefined</span><span class=pl-kos>,</span> <span class=pl-c1>undefined</span><span class=pl-kos>]</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L295">295</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC295">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>cvImages</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L296">296</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC296">        <span class=pl-s1>mergedMaps</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-en>computeMergedMap</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L297">297</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC297">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L298">298</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC298">    <span class=pl-s1>normalizedMaps</span> <span class=pl-c1>=</span> <span class=pl-en>normalizeMergedMaps</span><span class=pl-kos>(</span><span class=pl-s1>mergedMaps</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L299">299</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC299">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>mergedMaps</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L300">300</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC300">        <span class=pl-k>let</span> <span class=pl-s1>canvasId</span> <span class=pl-c1>=</span> <span class=pl-s>`__mnweight_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>i</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L301">301</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC301">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>imshow</span><span class=pl-kos>(</span><span class=pl-s1>canvasId</span><span class=pl-kos>,</span> <span class=pl-s1>normalizedMaps</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L302">302</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC302">        <span class=pl-s1>mergedMaps</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L303">303</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC303">        <span class=pl-s1>normalizedMaps</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L304">304</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC304">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L305">305</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC305">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L306">306</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC306">    <span class=pl-s1>loggingElement</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L307">307</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC307"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L308">308</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC308">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L309">309</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC309"><span class=pl-k>function</span> <span class=pl-en>singleImageProcess</span><span class=pl-kos>(</span><span class=pl-s1>image</span><span class=pl-kos>,</span> <span class=pl-s1>weight</span><span class=pl-kos>,</span> <span class=pl-s1>resultPyrs</span><span class=pl-kos>,</span> <span class=pl-s1>imageIndex</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L310">310</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC310">    <span class=pl-k>let</span> <span class=pl-s1>imagef32</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L311">311</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC311">    <span class=pl-s1>image</span><span class=pl-kos>.</span><span class=pl-en>convertTo</span><span class=pl-kos>(</span><span class=pl-s1>imagef32</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_32FC4</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L312">312</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC312">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L313">313</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC313">    <span class=pl-k>let</span> <span class=pl-s1>imagePyrs</span> <span class=pl-c1>=</span> <span class=pl-kos>[</span><span class=pl-s1>imagef32</span><span class=pl-kos>]</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L314">314</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC314">    <span class=pl-k>let</span> <span class=pl-s1>weightPyrs</span> <span class=pl-c1>=</span> <span class=pl-kos>[</span><span class=pl-s1>weight</span><span class=pl-kos>.</span><span class=pl-en>clone</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>]</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L315">315</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC315">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>l</span> <span class=pl-c1>=</span> <span class=pl-c1>1</span><span class=pl-kos>;</span> <span class=pl-s1>l</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>maxPyrLevel</span><span class=pl-kos>;</span> <span class=pl-s1>l</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L316">316</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC316">        <span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L317">317</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC317">        <span class=pl-s1>weightPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L318">318</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC318">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>pyrDown</span><span class=pl-kos>(</span><span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span> <span class=pl-c1>-</span> <span class=pl-c1>1</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Size</span><span class=pl-kos>(</span><span class=pl-c1>0</span><span class=pl-kos>,</span> <span class=pl-c1>0</span><span class=pl-kos>,</span> <span class=pl-c1>0</span><span class=pl-kos>)</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>BORDER_DEFAULT</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L319">319</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC319">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>pyrDown</span><span class=pl-kos>(</span><span class=pl-s1>weightPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span> <span class=pl-c1>-</span> <span class=pl-c1>1</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-s1>weightPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Size</span><span class=pl-kos>(</span><span class=pl-c1>0</span><span class=pl-kos>,</span> <span class=pl-c1>0</span><span class=pl-kos>)</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>BORDER_DEFAULT</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L320">320</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC320">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L321">321</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC321">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L322">322</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC322">    <span class=pl-c>// Laplacian of image</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L323">323</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC323">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>l</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>l</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>maxPyrLevel</span> <span class=pl-c1>-</span> <span class=pl-c1>1</span><span class=pl-kos>;</span> <span class=pl-s1>l</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L324">324</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC324">        <span class=pl-k>let</span> <span class=pl-s1>up</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>size</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_16S</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L325">325</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC325">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>pyrUp</span><span class=pl-kos>(</span><span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span> <span class=pl-c1>+</span> <span class=pl-c1>1</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-s1>up</span><span class=pl-kos>,</span> <span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>size</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L326">326</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC326">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>subtract</span><span class=pl-kos>(</span><span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-s1>up</span><span class=pl-kos>,</span> <span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L327">327</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC327">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L328">328</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC328">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L329">329</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC329">    <span class=pl-c>// Visualization</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L330">330</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC330">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>l</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>l</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>maxPyrLevel</span><span class=pl-kos>;</span> <span class=pl-s1>l</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L331">331</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC331">        <span class=pl-k>let</span> <span class=pl-s1>tmp</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L332">332</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC332">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>normalize</span><span class=pl-kos>(</span><span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-s1>tmp</span><span class=pl-kos>,</span> <span class=pl-c1>0</span><span class=pl-kos>,</span> <span class=pl-c1>1</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>NORM_MINMAX</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L333">333</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC333">        <span class=pl-s1>tmp</span><span class=pl-kos>.</span><span class=pl-en>convertTo</span><span class=pl-kos>(</span><span class=pl-s1>tmp</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_8UC4</span><span class=pl-kos>,</span> <span class=pl-c1>255</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L334">334</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC334">        <span class=pl-k>let</span> <span class=pl-s1>imagePyrCanvasId</span> <span class=pl-c1>=</span> <span class=pl-s>`_image_pyr_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>l</span><span class=pl-kos>}</span></span>_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>imageIndex</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L335">335</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC335">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>imshow</span><span class=pl-kos>(</span><span class=pl-s1>imagePyrCanvasId</span><span class=pl-kos>,</span> <span class=pl-s1>tmp</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L336">336</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC336">        <span class=pl-s1>tmp</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L337">337</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC337">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L338">338</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC338">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L339">339</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC339">        <span class=pl-k>let</span> <span class=pl-s1>weightPyrCanvasId</span> <span class=pl-c1>=</span> <span class=pl-s>`_weight_pyr_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>l</span><span class=pl-kos>}</span></span>_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>imageIndex</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L340">340</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC340">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>imshow</span><span class=pl-kos>(</span><span class=pl-s1>weightPyrCanvasId</span><span class=pl-kos>,</span> <span class=pl-s1>weightPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L341">341</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC341">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L342">342</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC342">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L343">343</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC343">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>l</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>l</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>maxPyrLevel</span><span class=pl-kos>;</span> <span class=pl-s1>l</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L344">344</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC344">        <span class=pl-k>let</span> <span class=pl-s1>merged</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>size</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_32FC4</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L345">345</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC345">        <span class=pl-k>let</span> <span class=pl-s1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-c1>cols</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L346">346</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC346">        <span class=pl-k>let</span> <span class=pl-s1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-c1>rows</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L347">347</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC347">        <span class=pl-k>let</span> <span class=pl-s1>channels</span> <span class=pl-c1>=</span> <span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>channels</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L348">348</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC348">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>y</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>y</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>height</span><span class=pl-kos>;</span> <span class=pl-s1>y</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L349">349</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC349">            <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>x</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>x</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>width</span><span class=pl-kos>;</span> <span class=pl-s1>x</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L350">350</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC350">                <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>c</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>c</span> <span class=pl-c1>&lt;</span> <span class=pl-c1>3</span><span class=pl-kos>;</span> <span class=pl-s1>c</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L351">351</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC351">                    <span class=pl-s1>merged</span><span class=pl-kos>.</span><span class=pl-en>floatPtr</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>[</span><span class=pl-s1>c</span><span class=pl-kos>]</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L352">352</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC352">                        <span class=pl-c1>=</span> <span class=pl-s1>imagePyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>floatAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span> <span class=pl-c1>*</span> <span class=pl-s1>channels</span> <span class=pl-c1>+</span> <span class=pl-s1>c</span><span class=pl-kos>)</span> <span class=pl-c1>*</span> <span class=pl-s1>weightPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>floatAt</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L353">353</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC353">                <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L354">354</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC354">                <span class=pl-c>// merged.floatPtr(y, x)[3] = imagePyrs[l].floatAt(y, x * channels + 3);</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L355">355</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC355">                <span class=pl-s1>merged</span><span class=pl-kos>.</span><span class=pl-en>floatPtr</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>[</span><span class=pl-c1>3</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-c1>255</span> <span class=pl-c1>/</span> <span class=pl-c1>3</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L356">356</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC356">            <span class=pl-kos>}</span>   </div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L357">357</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC357">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L358">358</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC358">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L359">359</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC359">        <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-s1>resultPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span> <span class=pl-c1>==</span> <span class=pl-c1>undefined</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L360">360</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC360">            <span class=pl-s1>resultPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-s1>merged</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L361">361</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC361">        <span class=pl-kos>}</span> <span class=pl-k>else</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L362">362</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC362">            <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>add</span><span class=pl-kos>(</span><span class=pl-s1>resultPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-s1>merged</span><span class=pl-kos>,</span> <span class=pl-s1>resultPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L363">363</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC363">            <span class=pl-s1>merged</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L364">364</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC364">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L365">365</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC365">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L366">366</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC366"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L367">367</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC367">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L368">368</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC368"><span class=pl-k>function</span> <span class=pl-en>finalImage</span><span class=pl-kos>(</span><span class=pl-s1>resultPyrs</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L369">369</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC369">    <span class=pl-k>function</span> <span class=pl-en>makeAlphaVisible</span><span class=pl-kos>(</span><span class=pl-s1>mat</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L370">370</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC370">        <span class=pl-k>let</span> <span class=pl-s1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>mat</span><span class=pl-kos>.</span><span class=pl-c1>cols</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L371">371</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC371">        <span class=pl-k>let</span> <span class=pl-s1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>mat</span><span class=pl-kos>.</span><span class=pl-c1>rows</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L372">372</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC372">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>y</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>y</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>height</span><span class=pl-kos>;</span> <span class=pl-s1>y</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L373">373</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC373">            <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>x</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>x</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>width</span><span class=pl-kos>;</span> <span class=pl-s1>x</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L374">374</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC374">                <span class=pl-s1>mat</span><span class=pl-kos>.</span><span class=pl-en>floatPtr</span><span class=pl-kos>(</span><span class=pl-s1>y</span><span class=pl-kos>,</span> <span class=pl-s1>x</span><span class=pl-kos>)</span><span class=pl-kos>[</span><span class=pl-c1>3</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-c1>255</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L375">375</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC375">            <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L376">376</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC376">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L377">377</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC377">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L378">378</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC378">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L379">379</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC379">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>l</span> <span class=pl-c1>=</span> <span class=pl-s1>maxPyrLevel</span> <span class=pl-c1>-</span> <span class=pl-c1>1</span><span class=pl-kos>;</span> <span class=pl-s1>l</span> <span class=pl-c1>&gt;</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>l</span><span class=pl-c1>--</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L380">380</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC380">        <span class=pl-k>let</span> <span class=pl-s1>up</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L381">381</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC381">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>pyrUp</span><span class=pl-kos>(</span><span class=pl-s1>resultPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-s1>up</span><span class=pl-kos>,</span> <span class=pl-s1>resultPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span> <span class=pl-c1>-</span> <span class=pl-c1>1</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>size</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L382">382</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC382">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>add</span><span class=pl-kos>(</span><span class=pl-s1>resultPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span> <span class=pl-c1>-</span> <span class=pl-c1>1</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-s1>up</span><span class=pl-kos>,</span> <span class=pl-s1>resultPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span> <span class=pl-c1>-</span> <span class=pl-c1>1</span><span class=pl-kos>]</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L383">383</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC383">        <span class=pl-k>let</span> <span class=pl-s1>canvasId</span> <span class=pl-c1>=</span> <span class=pl-s>`__pyrup_hdr_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>l</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L384">384</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC384">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L385">385</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC385">        <span class=pl-k>let</span> <span class=pl-s1>tmp</span> <span class=pl-c1>=</span> <span class=pl-s1>resultPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>clone</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L386">386</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC386">        <span class=pl-en>makeAlphaVisible</span><span class=pl-kos>(</span><span class=pl-s1>tmp</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L387">387</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC387">        <span class=pl-s1>tmp</span><span class=pl-kos>.</span><span class=pl-en>convertTo</span><span class=pl-kos>(</span><span class=pl-s1>tmp</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_8UC4</span><span class=pl-kos>,</span> <span class=pl-c1>1</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L388">388</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC388">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>imshow</span><span class=pl-kos>(</span><span class=pl-s1>canvasId</span><span class=pl-kos>,</span> <span class=pl-s1>tmp</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L389">389</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC389">        <span class=pl-s1>tmp</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L390">390</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC390">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L391">391</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC391">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L392">392</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC392">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L393">393</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC393">    <span class=pl-c>// visualization</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L394">394</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC394">    <span class=pl-k>let</span> <span class=pl-s1>tmp</span> <span class=pl-c1>=</span> <span class=pl-s1>resultPyrs</span><span class=pl-kos>[</span><span class=pl-c1>0</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>clone</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L395">395</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC395">    <span class=pl-en>makeAlphaVisible</span><span class=pl-kos>(</span><span class=pl-s1>tmp</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L396">396</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC396">    <span class=pl-s1>tmp</span><span class=pl-kos>.</span><span class=pl-en>convertTo</span><span class=pl-kos>(</span><span class=pl-s1>tmp</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_8UC4</span><span class=pl-kos>,</span> <span class=pl-c1>1</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L397">397</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC397">    <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>imshow</span><span class=pl-kos>(</span><span class=pl-s>&#39;__pyrup_hdr_0&#39;</span><span class=pl-kos>,</span> <span class=pl-s1>tmp</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L398">398</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC398">    <span class=pl-s1>tmp</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L399">399</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC399"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L400">400</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC400">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L401">401</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC401"><span class=pl-k>function</span> <span class=pl-en>computePyramidalResult</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L402">402</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC402">    <span class=pl-s1>mergedMaps</span> <span class=pl-c1>=</span> <span class=pl-kos>[</span><span class=pl-c1>undefined</span><span class=pl-kos>,</span> <span class=pl-c1>undefined</span><span class=pl-kos>,</span> <span class=pl-c1>undefined</span><span class=pl-kos>]</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L403">403</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC403">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>cvImages</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L404">404</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC404">        <span class=pl-s1>mergedMaps</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span> <span class=pl-c1>=</span> <span class=pl-en>computeMergedMap</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L405">405</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC405">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L406">406</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC406">    <span class=pl-s1>normalizedMaps</span> <span class=pl-c1>=</span> <span class=pl-en>normalizeMergedMaps</span><span class=pl-kos>(</span><span class=pl-s1>mergedMaps</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L407">407</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC407">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>cvImages</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L408">408</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC408">        <span class=pl-s1>mergedMaps</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L409">409</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC409">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L410">410</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC410">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L411">411</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC411">    <span class=pl-c>// cvImages + normalizedMaps</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L412">412</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC412">    <span class=pl-k>let</span> <span class=pl-s1>resultPyrs</span> <span class=pl-c1>=</span> <span class=pl-kos>[</span><span class=pl-kos>]</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L413">413</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC413">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>l</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>l</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>maxPyrLevel</span><span class=pl-kos>;</span> <span class=pl-s1>l</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L414">414</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC414">        <span class=pl-s1>resultPyrs</span><span class=pl-kos>.</span><span class=pl-en>push</span><span class=pl-kos>(</span><span class=pl-c1>undefined</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L415">415</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC415">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L416">416</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC416">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L417">417</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC417">    <span class=pl-k>let</span> <span class=pl-s1>imageCount</span> <span class=pl-c1>=</span> <span class=pl-s1>cvImages</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L418">418</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC418">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>imageCount</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L419">419</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC419">        <span class=pl-en>singleImageProcess</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-s1>normalizedMaps</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-s1>resultPyrs</span><span class=pl-kos>,</span> <span class=pl-s1>i</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L420">420</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC420">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L421">421</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC421">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L422">422</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC422">    <span class=pl-c>// Visualization</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L423">423</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC423">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>l</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>l</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>maxPyrLevel</span><span class=pl-kos>;</span> <span class=pl-s1>l</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L424">424</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC424">        <span class=pl-k>let</span> <span class=pl-s1>tmp</span> <span class=pl-c1>=</span> <span class=pl-k>new</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>Mat</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L425">425</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC425">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>normalize</span><span class=pl-kos>(</span><span class=pl-s1>resultPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>,</span> <span class=pl-s1>tmp</span><span class=pl-kos>,</span> <span class=pl-c1>0</span><span class=pl-kos>,</span> <span class=pl-c1>1</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>NORM_MINMAX</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L426">426</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC426">        <span class=pl-s1>tmp</span><span class=pl-kos>.</span><span class=pl-en>convertTo</span><span class=pl-kos>(</span><span class=pl-s1>tmp</span><span class=pl-kos>,</span> <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-c1>CV_8UC4</span><span class=pl-kos>,</span> <span class=pl-c1>255</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L427">427</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC427">        <span class=pl-k>let</span> <span class=pl-s1>imagePyrCanvasId</span> <span class=pl-c1>=</span> <span class=pl-s>`_fused_pyr_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>l</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L428">428</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC428">        <span class=pl-s1>cv</span><span class=pl-kos>.</span><span class=pl-en>imshow</span><span class=pl-kos>(</span><span class=pl-s1>imagePyrCanvasId</span><span class=pl-kos>,</span> <span class=pl-s1>tmp</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L429">429</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC429">        <span class=pl-s1>tmp</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L430">430</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC430">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L431">431</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC431">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L432">432</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC432">    <span class=pl-en>finalImage</span><span class=pl-kos>(</span><span class=pl-s1>resultPyrs</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L433">433</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC433">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L434">434</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC434">    <span class=pl-c>// Clan up</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L435">435</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC435">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>imageCount</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L436">436</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC436">        <span class=pl-s1>normalizedMaps</span><span class=pl-kos>[</span><span class=pl-s1>i</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L437">437</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC437">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L438">438</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC438">    <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>l</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>l</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>maxPyrLevel</span><span class=pl-kos>;</span> <span class=pl-s1>l</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L439">439</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC439">        <span class=pl-s1>resultPyrs</span><span class=pl-kos>[</span><span class=pl-s1>l</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-en>delete</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L440">440</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC440">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L441">441</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC441"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L442">442</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC442">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L443">443</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC443"><span class=pl-k>function</span> <span class=pl-en>computePyramidalResultUi</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L444">444</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC444">    <span class=pl-k>let</span> <span class=pl-s1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>cvImages</span><span class=pl-kos>[</span><span class=pl-c1>0</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-c1>cols</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L445">445</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC445">    <span class=pl-k>let</span> <span class=pl-s1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>cvImages</span><span class=pl-kos>[</span><span class=pl-c1>0</span><span class=pl-kos>]</span><span class=pl-kos>.</span><span class=pl-c1>rows</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L446">446</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC446">    <span class=pl-k>let</span> <span class=pl-s1>loggingElement</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L447">447</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC447">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L448">448</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC448">    <span class=pl-k>function</span> <span class=pl-en>renderUi</span><span class=pl-kos>(</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L449">449</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC449">        <span class=pl-s1>loggingElement</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L450">450</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC450">        <span class=pl-s1>pyrMmergeCanvas</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L451">451</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC451">        <span class=pl-s1>pyrMmergeCanvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>loggingElement</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L452">452</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC452">        <span class=pl-s1>loggingElement</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;Computing weights...&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L453">453</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC453">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L454">454</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC454">        <span class=pl-k>let</span> <span class=pl-s1>canvas</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L455">455</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC455">        <span class=pl-s1>pyrMmergeCanvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>canvas</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L456">456</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC456">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L457">457</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC457">        <span class=pl-k>let</span> <span class=pl-s1>rowHeaderImageDecomposition</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L458">458</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC458">        <span class=pl-s1>rowHeaderImageDecomposition</span><span class=pl-kos>.</span><span class=pl-c1>className</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;weight_header&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L459">459</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC459">        <span class=pl-s1>rowHeaderImageDecomposition</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;Image Decomposition&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L460">460</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC460">        <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>rowHeaderImageDecomposition</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L461">461</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC461">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L462">462</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC462">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>l</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>l</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>maxPyrLevel</span><span class=pl-kos>;</span> <span class=pl-s1>l</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L463">463</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC463">            <span class=pl-k>let</span> <span class=pl-s1>rowDiv</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L464">464</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC464">            <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>cvImages</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L465">465</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC465">                <span class=pl-k>let</span> <span class=pl-s1>canvas</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;canvas&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L466">466</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC466">                <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>id</span> <span class=pl-c1>=</span> <span class=pl-s>`_image_pyr_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>l</span><span class=pl-kos>}</span></span>_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>i</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L467">467</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC467">                <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>className</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;weight_canvas&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L468">468</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC468">                <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>width</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L469">469</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC469">                <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>height</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L470">470</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC470">                <span class=pl-s1>rowDiv</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>canvas</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L471">471</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC471">            <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L472">472</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC472">            <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>rowDiv</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L473">473</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC473">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L474">474</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC474">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L475">475</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC475">        <span class=pl-k>let</span> <span class=pl-s1>rowHeaderWeightDecomposition</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&quot;div&quot;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L476">476</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC476">        <span class=pl-s1>rowHeaderWeightDecomposition</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;Weights Decomposition&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L477">477</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC477">        <span class=pl-s1>rowHeaderWeightDecomposition</span><span class=pl-kos>.</span><span class=pl-c1>className</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;weight_header&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L478">478</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC478">        <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>rowHeaderWeightDecomposition</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L479">479</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC479">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>l</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>l</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>maxPyrLevel</span><span class=pl-kos>;</span> <span class=pl-s1>l</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L480">480</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC480">            <span class=pl-k>let</span> <span class=pl-s1>rowDiv</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L481">481</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC481">            <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>cvImages</span><span class=pl-kos>.</span><span class=pl-c1>length</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L482">482</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC482">                <span class=pl-k>let</span> <span class=pl-s1>canvas</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;canvas&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L483">483</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC483">                <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>id</span> <span class=pl-c1>=</span> <span class=pl-s>`_weight_pyr_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>l</span><span class=pl-kos>}</span></span>_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>i</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L484">484</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC484">                <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>className</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;weight_canvas&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L485">485</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC485">                <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>width</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L486">486</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC486">                <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-c1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>height</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L487">487</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC487">                <span class=pl-s1>rowDiv</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>canvas</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L488">488</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC488">            <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L489">489</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC489">            <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>rowDiv</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L490">490</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC490">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L491">491</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC491">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L492">492</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC492">        <span class=pl-k>let</span> <span class=pl-s1>finalMergeDecomposition</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&quot;div&quot;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L493">493</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC493">        <span class=pl-s1>finalMergeDecomposition</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;Fusion decomposition&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L494">494</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC494">        <span class=pl-s1>finalMergeDecomposition</span><span class=pl-kos>.</span><span class=pl-c1>className</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;weight_header&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L495">495</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC495">        <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>finalMergeDecomposition</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L496">496</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC496">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>l</span> <span class=pl-c1>=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>l</span> <span class=pl-c1>&lt;</span> <span class=pl-s1>maxPyrLevel</span><span class=pl-kos>;</span> <span class=pl-s1>l</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L497">497</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC497">            <span class=pl-k>let</span> <span class=pl-s1>rowDiv</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L498">498</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC498">            <span class=pl-k>let</span> <span class=pl-s1>canvasElement</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;canvas&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L499">499</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC499">            <span class=pl-s1>canvasElement</span><span class=pl-kos>.</span><span class=pl-c1>id</span> <span class=pl-c1>=</span> <span class=pl-s>`_fused_pyr_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>l</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L500">500</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC500">            <span class=pl-s1>canvasElement</span><span class=pl-kos>.</span><span class=pl-c1>className</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;weight_canvas&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L501">501</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC501">            <span class=pl-s1>canvasElement</span><span class=pl-kos>.</span><span class=pl-c1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>width</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L502">502</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC502">            <span class=pl-s1>canvasElement</span><span class=pl-kos>.</span><span class=pl-c1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>height</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L503">503</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC503">            <span class=pl-s1>rowDiv</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>canvasElement</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L504">504</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC504">            <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>rowDiv</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L505">505</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC505">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L506">506</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC506">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L507">507</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC507">        <span class=pl-k>let</span> <span class=pl-s1>finalHdrImage</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&quot;div&quot;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L508">508</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC508">        <span class=pl-s1>finalHdrImage</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;Final pyramid up and HDR Image generation&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L509">509</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC509">        <span class=pl-s1>finalHdrImage</span><span class=pl-kos>.</span><span class=pl-c1>className</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;weight_header&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L510">510</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC510">        <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>finalHdrImage</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L511">511</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC511">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>l</span> <span class=pl-c1>=</span> <span class=pl-s1>maxPyrLevel</span> <span class=pl-c1>-</span> <span class=pl-c1>1</span><span class=pl-kos>;</span> <span class=pl-s1>l</span> <span class=pl-c1>&gt;=</span> <span class=pl-c1>0</span><span class=pl-kos>;</span> <span class=pl-s1>l</span><span class=pl-c1>--</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L512">512</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC512">            <span class=pl-k>let</span> <span class=pl-s1>rowDiv</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;div&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L513">513</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC513">            <span class=pl-k>let</span> <span class=pl-s1>canvasElement</span> <span class=pl-c1>=</span> <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>createElement</span><span class=pl-kos>(</span><span class=pl-s>&#39;canvas&#39;</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L514">514</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC514">            <span class=pl-s1>canvasElement</span><span class=pl-kos>.</span><span class=pl-c1>id</span> <span class=pl-c1>=</span> <span class=pl-s>`__pyrup_hdr_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>l</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L515">515</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC515">            <span class=pl-s1>canvasElement</span><span class=pl-kos>.</span><span class=pl-c1>className</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;weight_canvas&#39;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L516">516</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC516">            <span class=pl-s1>canvasElement</span><span class=pl-kos>.</span><span class=pl-c1>width</span> <span class=pl-c1>=</span> <span class=pl-s1>width</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L517">517</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC517">            <span class=pl-s1>canvasElement</span><span class=pl-kos>.</span><span class=pl-c1>height</span> <span class=pl-c1>=</span> <span class=pl-s1>height</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L518">518</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC518">            <span class=pl-s1>rowDiv</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>canvasElement</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L519">519</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC519">            <span class=pl-s1>canvas</span><span class=pl-kos>.</span><span class=pl-en>appendChild</span><span class=pl-kos>(</span><span class=pl-s1>rowDiv</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L520">520</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC520">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L521">521</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC521">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L522">522</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC522">        <span class=pl-s1>loggingElement</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L523">523</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC523">    <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L524">524</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC524">    <span class=pl-en>renderUi</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L525">525</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC525">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L526">526</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC526">    <span class=pl-en>computePyramidalResult</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L527">527</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC527"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L528">528</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC528">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L529">529</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC529"><span class=pl-k>function</span> <span class=pl-en>clearCanvas</span><span class=pl-kos>(</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L530">530</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC530">    <span class=pl-s1>weightsCanvas</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L531">531</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC531">    <span class=pl-s1>mnWeightsCanvas</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L532">532</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC532">    <span class=pl-s1>pyrMmergeCanvas</span><span class=pl-kos>.</span><span class=pl-c1>innerHTML</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;&quot;</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L533">533</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC533"><span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L534">534</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC534">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L535">535</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC535"><span class=pl-k>function</span> <span class=pl-en>setupEfCanvas</span><span class=pl-kos>(</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L536">536</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC536">    <span class=pl-en>loadAllImages</span><span class=pl-kos>(</span><span class=pl-k>function</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L537">537</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC537">        <span class=pl-en>computeWeights</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L538">538</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC538">        <span class=pl-en>computeMergedWeights</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L539">539</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC539">        <span class=pl-en>computePyramidalResultUi</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L540">540</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC540">    <span class=pl-kos>}</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L541">541</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC541">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L542">542</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC542">    <span class=pl-k>let</span> <span class=pl-s1>currentSelectedDataset</span> <span class=pl-c1>=</span> <span class=pl-s1>datasetSelector</span><span class=pl-kos>.</span><span class=pl-c1>value</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L543">543</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC543">    <span class=pl-s1>datasetSelector</span><span class=pl-kos>.</span><span class=pl-en>addEventListener</span><span class=pl-kos>(</span><span class=pl-s>&#39;change&#39;</span><span class=pl-kos>,</span> <span class=pl-k>function</span><span class=pl-kos>(</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L544">544</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC544">        <span class=pl-k>let</span> <span class=pl-s1>selectedDataset</span> <span class=pl-c1>=</span> <span class=pl-s1>datasetSelector</span><span class=pl-kos>.</span><span class=pl-c1>value</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L545">545</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC545">        <span class=pl-k>if</span> <span class=pl-kos>(</span><span class=pl-s1>selectedDataset</span> <span class=pl-c1>==</span> <span class=pl-s1>currentSelectedDataset</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L546">546</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC546">            <span class=pl-k>return</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L547">547</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC547">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L548">548</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC548">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L549">549</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC549">        <span class=pl-en>clearCanvas</span><span class=pl-kos>(</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L550">550</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC550">        <span class=pl-k>for</span> <span class=pl-kos>(</span><span class=pl-k>let</span> <span class=pl-s1>i</span> <span class=pl-c1>=</span> <span class=pl-c1>1</span><span class=pl-kos>;</span> <span class=pl-s1>i</span> <span class=pl-c1>&lt;=</span> <span class=pl-c1>3</span><span class=pl-kos>;</span> <span class=pl-s1>i</span><span class=pl-c1>++</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L551">551</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC551">            <span class=pl-smi>document</span><span class=pl-kos>.</span><span class=pl-en>getElementById</span><span class=pl-kos>(</span><span class=pl-s>`input_<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>i</span><span class=pl-kos>}</span></span>`</span><span class=pl-kos>)</span><span class=pl-kos>.</span><span class=pl-c1>src</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L552">552</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC552">                <span class=pl-c1>=</span> <span class=pl-s>`/assets/research/exposure_fusion/<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>selectedDataset</span><span class=pl-kos>}</span></span>/<span class=pl-s1><span class=pl-kos>${</span><span class=pl-s1>i</span><span class=pl-kos>}</span></span>.jpg`</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L553">553</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC553">        <span class=pl-kos>}</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L554">554</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC554">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L555">555</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC555">        <span class=pl-en>loadAllImages</span><span class=pl-kos>(</span><span class=pl-k>function</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span> <span class=pl-kos>{</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L556">556</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC556">            <span class=pl-en>computeWeights</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L557">557</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC557">            <span class=pl-en>computeMergedWeights</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L558">558</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC558">            <span class=pl-en>computePyramidalResultUi</span><span class=pl-kos>(</span><span class=pl-s1>cvImages</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L559">559</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC559">        <span class=pl-kos>}</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L560">560</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC560">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L561">561</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC561">        <span class=pl-s1>currentSelectedDataset</span> <span class=pl-c1>=</span> <span class=pl-s1>selectedDataset</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L562">562</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC562">    <span class=pl-kos>}</span><span class=pl-kos>)</span><span class=pl-kos>;</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num color-bg-subtle js-line-number" id="L563">563</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC563"><span class=pl-kos>}</span></div>
                </div>
            </div>
          </div>
      </div>
    </div>

  </div>

</div>


</div>

    </main>
  </div>

  </div>

          <footer class="footer width-full container-xl p-responsive" role="contentinfo">


  <div class="position-relative d-flex flex-items-center pb-2 f6 color-fg-muted border-top color-border-muted flex-column-reverse flex-lg-row flex-wrap flex-lg-nowrap mt-6 pt-6">
    <ul class="list-style-none d-flex flex-wrap col-0 col-lg-2 flex-justify-start flex-lg-justify-between mb-2 mb-lg-0">
      <li class="mt-2 mt-lg-0 d-flex flex-items-center">
        <a aria-label="Homepage" title="GitHub" class="footer-octicon mr-2" href="https://github.com">
          <svg aria-hidden="true" height="24" viewBox="0 0 16 16" version="1.1" width="24" data-view-component="true" class="octicon octicon-mark-github">
    <path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"></path>
</svg>
</a>        <span>
        &copy; 2022 GitHub, Inc.
        </span>
      </li>
    </ul>
    <ul class="list-style-none d-flex flex-wrap col-12 col-lg-8 flex-justify-center flex-lg-justify-between mb-2 mb-lg-0">
        <li class="mr-3 mr-lg-0"><a href="https://docs.github.com/en/github/site-policy/github-terms-of-service" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to terms&quot;,&quot;label&quot;:&quot;text:terms&quot;}">Terms</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://docs.github.com/en/github/site-policy/github-privacy-statement" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to privacy&quot;,&quot;label&quot;:&quot;text:privacy&quot;}">Privacy</a></li>
        <li class="mr-3 mr-lg-0"><a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to security&quot;,&quot;label&quot;:&quot;text:security&quot;}" href="https://github.com/security">Security</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://www.githubstatus.com/" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to status&quot;,&quot;label&quot;:&quot;text:status&quot;}">Status</a></li>
        <li class="mr-3 mr-lg-0"><a data-ga-click="Footer, go to help, text:Docs" href="https://docs.github.com">Docs</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://support.github.com?tags=dotcom-footer" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to contact&quot;,&quot;label&quot;:&quot;text:contact&quot;}">Contact GitHub</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://github.com/pricing" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to Pricing&quot;,&quot;label&quot;:&quot;text:Pricing&quot;}">Pricing</a></li>
      <li class="mr-3 mr-lg-0"><a href="https://docs.github.com" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to api&quot;,&quot;label&quot;:&quot;text:api&quot;}">API</a></li>
      <li class="mr-3 mr-lg-0"><a href="https://services.github.com" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to training&quot;,&quot;label&quot;:&quot;text:training&quot;}">Training</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://github.blog" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to blog&quot;,&quot;label&quot;:&quot;text:blog&quot;}">Blog</a></li>
        <li><a data-ga-click="Footer, go to about, text:about" href="https://github.com/about">About</a></li>
    </ul>
  </div>
  <div class="d-flex flex-justify-center pb-6">
    <span class="f6 color-fg-muted"></span>
  </div>
</footer>




  <div id="ajax-error-message" class="ajax-error-message flash flash-error" hidden>
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path fill-rule="evenodd" d="M8.22 1.754a.25.25 0 00-.44 0L1.698 13.132a.25.25 0 00.22.368h12.164a.25.25 0 00.22-.368L8.22 1.754zm-1.763-.707c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0114.082 15H1.918a1.75 1.75 0 01-1.543-2.575L6.457 1.047zM9 11a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z"></path>
</svg>
    <button type="button" class="flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
    </button>
    You can’t perform that action at this time.
  </div>

  <div class="js-stale-session-flash flash flash-warn flash-banner" hidden
    >
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path fill-rule="evenodd" d="M8.22 1.754a.25.25 0 00-.44 0L1.698 13.132a.25.25 0 00.22.368h12.164a.25.25 0 00.22-.368L8.22 1.754zm-1.763-.707c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0114.082 15H1.918a1.75 1.75 0 01-1.543-2.575L6.457 1.047zM9 11a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z"></path>
</svg>
    <span class="js-stale-session-flash-signed-in" hidden>You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
    <span class="js-stale-session-flash-signed-out" hidden>You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
  </div>
    <template id="site-details-dialog">
  <details class="details-reset details-overlay details-overlay-dark lh-default color-fg-default hx_rsm" open>
    <summary role="button" aria-label="Close dialog"></summary>
    <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast hx_rsm-dialog hx_rsm-modal">
      <button class="Box-btn-octicon m-0 btn-octicon position-absolute right-0 top-0" type="button" aria-label="Close dialog" data-close-dialog>
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
      </button>
      <div class="octocat-spinner my-6 js-details-dialog-spinner"></div>
    </details-dialog>
  </details>
</template>

    <div class="Popover js-hovercard-content position-absolute" style="display: none; outline: none;" tabindex="0">
  <div class="Popover-message Popover-message--bottom-left Popover-message--large Box color-shadow-large" style="width:360px;">
  </div>
</div>

    <template id="snippet-clipboard-copy-button">
  <div class="zeroclipboard-container position-absolute right-0 top-0">
    <clipboard-copy aria-label="Copy" class="ClipboardButton btn js-clipboard-copy m-2 p-0 tooltipped-no-delay" data-copy-feedback="Copied!" data-tooltip-direction="w">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copy js-clipboard-copy-icon m-2">
    <path fill-rule="evenodd" d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 010 1.5h-1.5a.25.25 0 00-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 00.25-.25v-1.5a.75.75 0 011.5 0v1.5A1.75 1.75 0 019.25 16h-7.5A1.75 1.75 0 010 14.25v-7.5z"></path><path fill-rule="evenodd" d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0114.25 11h-7.5A1.75 1.75 0 015 9.25v-7.5zm1.75-.25a.25.25 0 00-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 00.25-.25v-7.5a.25.25 0 00-.25-.25h-7.5z"></path>
</svg>
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check js-clipboard-check-icon color-fg-success d-none m-2">
    <path fill-rule="evenodd" d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"></path>
</svg>
    </clipboard-copy>
  </div>
</template>




  </body>
</html>

